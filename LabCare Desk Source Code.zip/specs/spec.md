# 1. Overview

## 1.1 Description

- App name: LabCare Desk
- Project goals and objectives:
  - Capture customer complaints and laboratory equipment breakdowns in one traceable queue.
  - Give support staff a clear path from report to resolution while preserving every change in ticket history.
  - Show current ticket status and equipment context consistently on web and phone-sized screens.
  - Notify relevant people in-app and through configured email and phone channels when a complaint is created or materially updated.

# 2. Requirements

## 2.1 Roles and Permission

| Role ID | Display Name | Description | Permission |
|---|---|---|---|
| root | Root | Full Access | Application development only; not a business user. |
| admin | Admin | Controls access and operations | Can view and update all tickets, register or archive equipment, configure notifications, and add or deactivate access-directory users. |
| support_team | Support Team | Handles service work | Can create tickets, update tickets, change status, assign support ownership, register or archive equipment, and view complete ticket history. |
| customer | Customer | Reports equipment issues | Can create tickets and update tickets they created, including additional evidence and contact details. |
| viewer | Viewer | Monitors service activity | Can view current tickets, equipment context, and ticket history without changing records. |

## 2.2 User Story

| US ID | As a | I want to | So that |
|---|---|---|---|
| US-01 | Customer | report a complaint or equipment breakdown with the affected equipment and symptoms | support can begin with enough context to respond. |
| US-02 | Support Team | triage, update, assign, and close service tickets | every issue moves through a visible service lifecycle. |
| US-03 | Customer | add clarification to a ticket I created | support has the latest evidence without creating duplicate tickets. |
| US-04 | Viewer | inspect the live queue and full history | I can understand current service activity without altering it. |
| US-05 | Admin | add or deactivate people in the access directory | access is controlled from one place. |
| US-06 | Admin | configure notification channels and recipients | new complaints reach the right people through app, email, and phone notification paths. |

## 2.3 First-Version Commitments

| FC ID | Capability | Minimum User Path | Related US |
|---|---|---|---|
| FC-01 | Complaint and breakdown ticket intake | Ticket Inbox -> New Ticket -> required complaint/equipment/contact fields -> seven-digit ticket saved in New state -> inbox row appears. | US-01 |
| FC-02 | Ticket triage and resolution lifecycle | Ticket row -> detail -> support update/status/owner -> saved state and history event -> current queue reflects change. | US-02 |
| FC-03 | Customer ticket follow-up | My ticket detail -> add update -> saved note/evidence -> history and notification record append. | US-03 |
| FC-04 | Equipment registry, context, and traceable history | Equipment Registry -> Add equipment -> asset and site details saved -> active equipment is selectable in New Ticket; ticket detail -> equipment panel and history timeline. | US-02, US-04 |
| FC-05 | Read-only monitoring access | Viewer opens Ticket Inbox -> filters/searches -> opens detail/history -> controls that change records are unavailable. | US-04 |
| FC-06 | Admin access directory | Access Control -> add person/role -> active directory row -> deactivate with confirmation and audit event. | US-05 |
| FC-07 | Multi-channel complaint notifications | New complaint saved -> in-app notification and email/phone delivery entries recorded -> notification status visible in activity panel. | US-06 |

# 3. Data Models

## 3.1 Ticket

- Description: A customer complaint or laboratory equipment breakdown requiring service follow-up.

| Field Name | Definition | Notes |
|---|---|---|
| Ticket ID | Numeric identifier formatted as exactly seven digits. | Generated sequentially; examples 2401001 and 2401002. |
| Type | `Complaint` or `Breakdown`. | Required. |
| Status | `New`, `Triaged`, `In Progress`, `Waiting on Customer`, `Resolved`, or `Closed`. | New tickets start in `New`; only support/admin can move service state, while customers can append updates to their own tickets. |
| Priority | `Low`, `Normal`, `High`, or `Urgent`. | Required; urgent items are visually highlighted. |
| Subject | Short issue summary. | Required. |
| Description | Symptoms, impact, and requested help. | Required. |
| Equipment | Specific instrument name, model, asset tag, and site/lab location. | Equipment name and asset tag required. |
| Creator | Person who opened the ticket. | Immutable creator reference and display name. |
| Assigned support | Current support owner. | Optional until triage. |
| Last update | Most recent change timestamp and actor. | Drives queue freshness. |

## 3.2 Ticket History Event

- Description: Append-only log of ticket creation, status changes, assignment, customer updates, support notes, and resolution details.

| Field Name | Definition | Notes |
|---|---|---|
| Event ID | Unique history record identifier. | Immutable. |
| Ticket ID | Ticket to which the event belongs. | Required. |
| Event type | `Created`, `Status changed`, `Assigned`, `Customer update`, `Support update`, or `Resolved`. | Required. |
| Message | Human-readable action or note. | Required. |
| Actor | Creator of the event. | Required. |
| Created at | Time the event was recorded. | Immutable. |
| Evidence | Optional attachment/reference label. | Visible in history when present. |

## 3.3 Equipment

- Description: Laboratory instrument referenced by one or more tickets.

| Field Name | Definition | Notes |
|---|---|---|
| Equipment ID | Unique equipment reference. | Required. |
| Name | Instrument name. | Required. |
| Model | Manufacturer model. | Optional when not available at registration. |
| Manufacturer | Equipment manufacturer. | Optional manufacturer name for service identification. |
| Serial number | Manufacturer serial identifier. | Optional and searchable for service verification. |
| Asset tag | Site asset identifier. | Required and searchable. |
| Site | Laboratory/site location. | Required. |
| Status | `Active` or `Archived`. | Archived equipment remains visible on historical tickets and is unavailable for new ticket selection. |
| Service contact | Optional local contact or phone. | Shown in ticket context. |

## 3.4 Access Directory User

- Description: App access record maintained by Admin; authentication remains controlled by the platform gateway. Pending invitations are recorded until a Gateway administrator provisions the account.

| Field Name | Definition | Notes |
|---|---|---|
| User ID | Directory identifier. | Required. |
| Name | Person's display name. | Required. |
| Email | Contact and notification address. | Required and unique. |
| Phone | Required phone number for notification routing. | Accepts an optional leading `+`, digits, spaces, hyphens, and parentheses; must contain 7–20 digits after normalization. |
| Role | `admin`, `support_team`, `customer`, or `viewer`. | Required. |
| Status | `Active` or `Inactive`. | Inactive users cannot be selected for assignment or notifications. |
| Added by / date | Admin actor and timestamp. | Audit trace. |
| Invitation | Pending email-based access request. | Admin-only; email, display name, phone, and role are required. The app records the pending request but does not send email or create Gateway accounts without a platform integration. |

## 3.5 Notification Delivery

- Description: Delivery attempt record generated from complaint creation or material ticket updates.

| Field Name | Definition | Notes |
|---|---|---|
| Notification ID | Unique delivery record. | Required. |
| Ticket ID | Related complaint/breakdown. | Required. |
| Channel | `In-app`, `Email`, or `Phone`. | One record per channel/recipient. |
| Recipient | Target person or routing label. | Required. |
| Status | `Queued`, `Sent`, or `Failed`. | Visible to Admin/support for traceability. |
| Created at | Time delivery was queued. | Immutable. |

# 4. Business Logic

## 4.1 Create and Number a Ticket

- Related user story: US-01
- Trigger: Customer, Support Team, or Admin submits the New Ticket form.
- Logic:
  1. Verify the actor has ticket-create permission and validate type, priority, subject, description, equipment name, asset tag, and site.
  2. Allocate the next numeric ticket sequence and format it with leading zeroes to exactly seven digits.
  3. Save the ticket in `New` state with the authenticated creator and create a `Created` history event in the same operation.
  4. Queue in-app, email, and phone notification delivery records for the configured recipients.
  5. Return the ticket detail and show it at the top of the queue.
- Output: Seven-digit ticket, persisted equipment context, creator, first history entry, and notification delivery statuses.

## 4.2 Triage, Update, and Resolve a Ticket

- Related user story: US-02
- Trigger: Support Team or Admin opens a ticket and submits a service update.
- Logic:
  1. Verify the actor can update the ticket and that the requested status transition is legal.
  2. Allow assignment, status, priority, and a required note when changing service state; allow resolution details for `Resolved`.
  3. Append a history event with actor, timestamp, before/after status where relevant, and note.
  4. Update the queue's last-activity marker and queue a material-update notification.
  5. Permit `Closed` only from `Resolved`; permit reopening a closed ticket only by Admin with a reason.
- Output: Updated ticket state, visible history event, and notification delivery records.

## 4.3 Customer Follow-up

- Related user story: US-03
- Trigger: Customer opens a ticket they created and submits an additional note or evidence label.
- Logic:
  1. Confirm the customer is the immutable creator and the ticket is not `Closed`.
  2. Save the note as a `Customer update` history event without allowing status, assignment, or creator changes.
  3. Move `Waiting on Customer` to `Triaged` when support reviews the update, not automatically on customer submission.
  4. Queue an in-app, email, and phone notification for the support routing group.
- Output: New append-only history entry and visible last-update change.

## 4.4 Equipment Registry

- Related user story: US-02
- Trigger: Admin or Support Team registers or archives a laboratory instrument.
- Logic:
  1. Require equipment-management permission and validate the unique asset tag, instrument name, and location/site.
  2. Save the equipment record as Active; manufacturer, model, and serial number remain optional service identifiers.
  3. Archive rather than delete an active record after confirmation; historical ticket equipment context remains intact and archived records cannot be selected on new tickets.
- Output: Persisted equipment record with an Active or Archived state available to the registry and ticket intake.

## 4.4 Access Directory Control

- Related user story: US-05
- Trigger: Admin opens Access Control and adds, invites, deactivates, or revokes access for a person.
- Logic:
  1. Require Admin permission; reject duplicate email addresses and unsupported roles.
  2. Add a directory record with Active status, or create a Pending invitation with normalized unique email, display name, phone, role, inviter, and timestamp; deactivate an existing record after showing the impact and requiring confirmation; allow an Admin to revoke a pending invitation.
  3. Never remove ticket history when a directory user is deactivated; preserve their name on past events.
  4. Record the Admin action in the access audit history.
- Output: Updated active/inactive directory and audit feedback.

## 4.5 Notification Routing

- Related user story: US-06
- Trigger: Ticket creation or material ticket update.
- Logic:
  1. Determine recipients from the creator, assigned support owner, support routing group, and Admin-configured notification settings.
  2. Create one delivery record for each selected channel and recipient, starting at `Queued`.
  3. The app shows in-app notifications immediately; email and phone records expose `Sent`/`Failed` outcome when an integration is available, otherwise remain clearly marked `Queued` for operational follow-up.
  4. Do not block ticket creation if one external channel fails; retain the failure in notification history.
- Output: Notification activity attached to the ticket and an Admin-visible channel summary.

# 5. UI

## 5.1 Ticket Inbox

- Purpose: Give every authorized role a direct view of current complaint and breakdown work.
- Key Elements: Queue summary counts, New Ticket button when permitted, status filters, bounded search for ticket ID/subject/asset tag, urgency markers, seven-digit IDs, equipment, creator, assigned support, last update, and current status.
- User Interaction Flow: User enters the inbox, filters or searches, opens a row to view detail, and sees action controls based on role. Viewer sees the same current data without create/update controls.
- Validation Rules: Search stays bounded on narrow screens; unsupported filters do not change records; every row links to a real ticket detail.

## 5.2 New Ticket

- Purpose: Capture a complete complaint or breakdown report without requiring a separate phone call.
- Key Elements: Type, priority, subject, description, equipment name/model/asset tag/site, reporter contact, optional evidence label, and clear notification acknowledgment.
- User Interaction Flow: User completes required fields, submits, receives the generated seven-digit ID, and is taken to the ticket detail with the first history and notification entries visible.
- Validation Rules: Type, priority, subject, description, equipment name, asset tag, and site are required; ticket ID is system-generated and cannot be edited; duplicate active reports for the same asset and matching subject prompt review before submission.

## 5.3 Ticket Detail and History

- Purpose: Provide one source of truth for the issue, equipment, current ownership, notification delivery, and append-only history.
- Key Elements: Ticket header/status, equipment card, creator and assignee, description, update form when permitted, history timeline, and notification delivery list.
- User Interaction Flow: User reviews the ticket, support/admin updates status/assignment/note, customer adds a follow-up note on owned tickets, and viewer reads the timeline. Success feedback and current state appear without leaving the record.
- Validation Rules: Illegal status transitions are rejected; closing requires a resolved ticket; customer cannot edit another creator's ticket or service status; every saved update requires a note and creates a history event.

## 5.4 Equipment Registry

- Purpose: Maintain the active laboratory equipment records that can be selected for service tickets.
- Key Elements: Searchable equipment list, equipment name, asset tag, manufacturer, model, serial number, location/site, active/archive state, Add equipment action for Admin and Support Team, and archive confirmation.
- User Interaction Flow: Admin or Support Team opens Equipment Registry, registers an asset, sees it in the active list, and can archive it after confirming its historical-ticket impact. Customer and Viewer can inspect equipment records without registration or archive controls.
- Validation Rules: Name, asset tag, and location/site are required; asset tag is unique; archived equipment remains on prior tickets and cannot be selected for a new ticket.

## 5.5 Access Control

- Purpose: Let Admin maintain who can access the service desk and which business role applies.
- Key Elements: Active/inactive directory, pending invitations, role selector, add known user form, invite-by-email form, deactivate/revoke confirmations, and access audit entries.
- User Interaction Flow: Admin adds a known Gateway user or records an email invitation with contact and role, sees the active or pending row, and can deactivate access or revoke a pending invitation after confirming the impact. Non-admin roles do not see this route.
- Validation Rules: Email, name, and phone are required for both known users and invitations; phone accepts an optional leading `+`, digits, spaces, hyphens, and parentheses and must contain 7–20 digits after normalization; email must be unique among active directory records and pending invitations; role must be one of the four business roles; deactivation and invitation revocation require confirmation and do not delete historical ticket events. Pending invitations are clearly marked as not yet sent/provisioned when no platform integration is configured.

## 5.6 Notification Settings

- Purpose: Make notification routing visible and manageable for Admin.
- Key Elements: In-app, email, and phone channel status; support routing recipients; recent delivery outcomes; and a test notification action.
- User Interaction Flow: Admin reviews channel routing, enables/disables a configured recipient, and sees the result on subsequent ticket notification activity.
- Validation Rules: At least one in-app route remains enabled; phone routing requires a phone number; external delivery errors are shown as failures rather than hidden.
