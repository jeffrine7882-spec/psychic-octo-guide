import { and, desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  equipment,
  insertEquipmentSchema,
  insertTicketSchema,
  notifications,
  ticketHistory,
  tickets,
  type NotificationChannel,
  type Ticket,
} from "@/db/schema";
import { bootstrapModule, type RuntimeTableBootstrap } from "@/services/bootstrap";
import { rowsOf } from "@/services/db-results";
import { seedTimestamp } from "@/services/seed-utils";
import type { AppUser } from "@/lib/users";
import { can, hasAnyRole } from "@/lib/permissions";
import { HttpError } from "@/lib/route-handlers";
import { z } from "zod";

const deliveryChannels = ["in_app", "email", "phone"] as const satisfies readonly NotificationChannel[];

const ticketTables: RuntimeTableBootstrap[] = [
  {
    table: equipment,
    prepare: [sql`do $$ begin create type ticket_type as enum ('complaint', 'breakdown'); exception when duplicate_object then null; end $$`, sql`do $$ begin create type ticket_status as enum ('new', 'triaged', 'in_progress', 'waiting_on_customer', 'resolved', 'closed'); exception when duplicate_object then null; end $$`, sql`do $$ begin create type ticket_priority as enum ('low', 'normal', 'high', 'urgent'); exception when duplicate_object then null; end $$`],
    createTable: sql`create table if not exists equipment (id text primary key, asset_tag text not null unique, name text not null, manufacturer text, model text, location text, serial_number text, is_active boolean not null default true, created_at timestamp not null default now(), updated_at timestamp not null default now())`,
    seed: async (tx) => {
      await tx.insert(equipment).values([
        { id: "eq-microscope-01", assetTag: "LC-MIC-001", name: "Inverted Microscope", manufacturer: "Nikon", model: "Eclipse Ti2", location: "Cell Culture Lab", serialNumber: "TI2-88421", createdAt: seedTimestamp(-30), updatedAt: seedTimestamp(-2) },
        { id: "eq-analyzer-02", assetTag: "LC-ANA-014", name: "Chemistry Analyzer", manufacturer: "Roche", model: "cobas c 311", location: "Core Lab", serialNumber: "C311-77104", createdAt: seedTimestamp(-25), updatedAt: seedTimestamp(-1) },
        { id: "eq-freezer-03", assetTag: "LC-FRZ-007", name: "Ultra-low Freezer", manufacturer: "Thermo Fisher", model: "TSX600", location: "Sample Archive", serialNumber: "TSX-19031", createdAt: seedTimestamp(-20), updatedAt: seedTimestamp(-4) },
      ]).onConflictDoNothing();
    },
  },
  {
    table: tickets,
    createTable: sql`create table if not exists tickets (ticket_number integer primary key, type ticket_type not null, status ticket_status not null default 'new', priority ticket_priority not null default 'normal', subject text not null, description text not null, equipment_id text references equipment(id), creator_id text not null, creator_name text not null, creator_email text, assigned_to text, resolution text, resolved_at timestamp, created_at timestamp not null default now(), updated_at timestamp not null default now())`,
    createIndexes: [sql`create index if not exists tickets_status_idx on tickets(status)`, sql`create index if not exists tickets_creator_idx on tickets(creator_id)`, sql`create index if not exists tickets_updated_idx on tickets(updated_at desc)`],
    seed: async (tx) => {
      await tx.insert(tickets).values([
        { ticketNumber: 1000001, type: "breakdown", status: "in_progress", priority: "urgent", subject: "Freezer temperature alarm", description: "The sample archive freezer is above -70°C and continues to alarm.", equipmentId: "eq-freezer-03", creatorId: "maya.chen", creatorName: "Maya Chen", creatorEmail: "maya.chen@labcare.example", assignedTo: "support-lee", createdAt: seedTimestamp(-2, 7), updatedAt: seedTimestamp(0, 8) },
        { ticketNumber: 1000002, type: "complaint", status: "waiting_on_customer", priority: "normal", subject: "Unexpected analyzer calibration warning", description: "Calibration warning appears after the morning control run; requesting guidance.", equipmentId: "eq-analyzer-02", creatorId: "oliver.grant", creatorName: "Oliver Grant", creatorEmail: "oliver.grant@labcare.example", assignedTo: "support-rina", createdAt: seedTimestamp(-1, 10), updatedAt: seedTimestamp(0, 9) },
        { ticketNumber: 1000003, type: "complaint", status: "resolved", priority: "high", subject: "Microscope illumination flickers", description: "Illumination flickers intermittently during imaging at 40x.", equipmentId: "eq-microscope-01", creatorId: "sana.patel", creatorName: "Sana Patel", creatorEmail: "sana.patel@labcare.example", assignedTo: "support-lee", resolution: "Replaced lamp module and verified stable illumination.", resolvedAt: seedTimestamp(-1, 15), createdAt: seedTimestamp(-7, 11), updatedAt: seedTimestamp(-1, 15) },
        { ticketNumber: 1000004, type: "complaint", status: "closed", priority: "low", subject: "Request for operating guide", description: "Please provide the current quick-start guide for the microscope.", equipmentId: "eq-microscope-01", creatorId: "noah.kim", creatorName: "Noah Kim", creatorEmail: "noah.kim@labcare.example", resolution: "Sent the approved operating guide.", resolvedAt: seedTimestamp(-10, 13), createdAt: seedTimestamp(-14, 9), updatedAt: seedTimestamp(-9, 13) },
      ]).onConflictDoNothing();
    },
  },
  {
    table: ticketHistory,
    createTable: sql`create table if not exists ticket_history (id text primary key, ticket_number integer not null references tickets(ticket_number), actor_id text not null, actor_name text not null, action text not null, from_status ticket_status, to_status ticket_status, note text, created_at timestamp not null default now(), updated_at timestamp not null default now())`,
    createIndexes: [sql`create index if not exists ticket_history_ticket_idx on ticket_history(ticket_number, created_at desc)`],
    seed: async (tx) => {
      await tx.insert(ticketHistory).values([
        { id: "hist-1000001-created", ticketNumber: 1000001, actorId: "maya.chen", actorName: "Maya Chen", action: "created", toStatus: "new", note: "Breakdown reported from Sample Archive.", createdAt: seedTimestamp(-2, 7), updatedAt: seedTimestamp(-2, 7) },
        { id: "hist-1000001-triaged", ticketNumber: 1000001, actorId: "support-lee", actorName: "Lee Wong", action: "triaged", fromStatus: "new", toStatus: "triaged", note: "Escalated due to temperature risk.", createdAt: seedTimestamp(-2, 8), updatedAt: seedTimestamp(-2, 8) },
        { id: "hist-1000001-progress", ticketNumber: 1000001, actorId: "support-lee", actorName: "Lee Wong", action: "status_changed", fromStatus: "triaged", toStatus: "in_progress", note: "Remote diagnostics started.", createdAt: seedTimestamp(0, 8), updatedAt: seedTimestamp(0, 8) },
        { id: "hist-1000003-resolved", ticketNumber: 1000003, actorId: "support-lee", actorName: "Lee Wong", action: "resolved", fromStatus: "in_progress", toStatus: "resolved", note: "Lamp module replaced and test passed.", createdAt: seedTimestamp(-1, 15), updatedAt: seedTimestamp(-1, 15) },
      ]).onConflictDoNothing();
    },
  },
  {
    table: notifications,
    prepare: [
      sql`do $$ begin create type notification_channel as enum ('in_app', 'email', 'phone'); exception when duplicate_object then null; end $$`,
      sql`do $$ begin create type notification_delivery_status as enum ('delivered', 'not_configured'); exception when duplicate_object then null; end $$`,
      sql`alter table if exists notifications add column if not exists channel notification_channel not null default 'in_app'`,
      sql`alter table if exists notifications add column if not exists delivery_status notification_delivery_status not null default 'delivered'`,
    ],
    createTable: sql`create table if not exists notifications (id text primary key, recipient_user_id text not null, ticket_number integer references tickets(ticket_number), kind text not null, title text not null, message text not null, channel notification_channel not null default 'in_app', delivery_status notification_delivery_status not null default 'delivered', read_at timestamp, created_at timestamp not null default now(), updated_at timestamp not null default now())`,
    createIndexes: [sql`create index if not exists notifications_recipient_idx on notifications(recipient_user_id, read_at, created_at desc)`, sql`create index if not exists notifications_ticket_channel_idx on notifications(ticket_number, channel, created_at desc)`],
    seed: async (tx) => {
      await tx.insert(notifications).values([
        { id: "notif-maya-freezer-app", recipientUserId: "maya.chen", ticketNumber: 1000001, kind: "ticket_update", title: "Ticket 1000001 in progress", message: "Support has started remote diagnostics on the freezer.", channel: "in_app", deliveryStatus: "delivered", createdAt: seedTimestamp(0, 8), updatedAt: seedTimestamp(0, 8) },
        { id: "notif-maya-freezer-email", recipientUserId: "maya.chen", ticketNumber: 1000001, kind: "ticket_update", title: "Ticket 1000001 in progress", message: "Support has started remote diagnostics on the freezer.", channel: "email", deliveryStatus: "not_configured", createdAt: seedTimestamp(0, 8), updatedAt: seedTimestamp(0, 8) },
        { id: "notif-maya-freezer-phone", recipientUserId: "maya.chen", ticketNumber: 1000001, kind: "ticket_update", title: "Ticket 1000001 in progress", message: "Support has started remote diagnostics on the freezer.", channel: "phone", deliveryStatus: "not_configured", createdAt: seedTimestamp(0, 8), updatedAt: seedTimestamp(0, 8) },
        { id: "notif-oliver-followup-app", recipientUserId: "oliver.grant", ticketNumber: 1000002, kind: "customer_action", title: "Information requested", message: "Please attach the latest analyzer control-run report.", channel: "in_app", deliveryStatus: "delivered", createdAt: seedTimestamp(0, 9), updatedAt: seedTimestamp(0, 9) },
        { id: "notif-oliver-followup-email", recipientUserId: "oliver.grant", ticketNumber: 1000002, kind: "customer_action", title: "Information requested", message: "Please attach the latest analyzer control-run report.", channel: "email", deliveryStatus: "not_configured", createdAt: seedTimestamp(0, 9), updatedAt: seedTimestamp(0, 9) },
        { id: "notif-oliver-followup-phone", recipientUserId: "oliver.grant", ticketNumber: 1000002, kind: "customer_action", title: "Information requested", message: "Please attach the latest analyzer control-run report.", channel: "phone", deliveryStatus: "not_configured", createdAt: seedTimestamp(0, 9), updatedAt: seedTimestamp(0, 9) },
      ]).onConflictDoNothing();
    },
  },
];

export const ticketCreateSchema = insertTicketSchema.pick({ type: true, priority: true, subject: true, description: true, equipmentId: true }).extend({
  type: z.enum(["complaint", "breakdown"]),
  priority: z.enum(["low", "normal", "high", "urgent"]).default("normal"),
  subject: z.string().trim().min(3).max(200),
  description: z.string().trim().min(5).max(5000),
  equipmentId: z.string().trim().min(1).nullable().optional(),
});
export const ticketUpdateSchema = ticketCreateSchema.partial().extend({
  status: z.enum(["new", "triaged", "in_progress", "waiting_on_customer", "resolved", "closed"]).optional(),
  assignedTo: z.string().trim().min(1).nullable().optional(),
  resolution: z.string().trim().min(3).max(5000).nullable().optional(),
  note: z.string().trim().max(2000).optional(),
});

export const equipmentCreateSchema = insertEquipmentSchema.pick({ assetTag: true, name: true, manufacturer: true, model: true, location: true, serialNumber: true }).extend({
  assetTag: z.string().trim().min(2).max(100),
  name: z.string().trim().min(2).max(200),
  manufacturer: z.string().trim().min(1).max(200).nullable().optional(),
  model: z.string().trim().min(1).max(200).nullable().optional(),
  location: z.string().trim().min(2).max(200),
  serialNumber: z.string().trim().min(1).max(200).nullable().optional(),
});

const bootstrap = bootstrapModule("labcare-tickets", ticketTables);

function deliveryRecords(recipientUserId: string, ticketNumber: number, kind: string, title: string, message: string) {
  return deliveryChannels.map((channel) => ({
    recipientUserId,
    ticketNumber,
    kind,
    title,
    message,
    channel,
    // External delivery is intentionally recorded, not attempted synchronously.
    // This keeps ticket work available when email/SMS providers are unavailable.
    deliveryStatus: channel === "in_app" ? ("delivered" as const) : ("not_configured" as const),
  }));
}

async function recordDeliveries(records: ReturnType<typeof deliveryRecords>) {
  try {
    await db.insert(notifications).values(records);
  } catch (error) {
    // Notification persistence is best-effort; ticket creation and updates are
    // already committed and must remain available if delivery storage is down.
    console.error("[notifications] unable to record delivery status:", error);
  }
}

export async function listEquipment(includeInactive = false) {
  await bootstrap;
  return db.select().from(equipment).where(includeInactive ? undefined : eq(equipment.isActive, true)).orderBy(desc(equipment.createdAt));
}

export async function createEquipment(input: z.infer<typeof equipmentCreateSchema>) {
  await bootstrap;
  return db.transaction(async (tx) => {
    const [existing] = await tx.select({ id: equipment.id }).from(equipment).where(eq(equipment.assetTag, input.assetTag)).limit(1);
    if (existing) throw new HttpError(409, "An equipment record already uses this asset tag");
    const [created] = await tx.insert(equipment).values(input).returning();
    return created;
  });
}

export async function deactivateEquipment(id: string) {
  await bootstrap;
  return db.transaction(async (tx) => {
    const [deactivated] = await tx.update(equipment).set({ isActive: false }).where(and(eq(equipment.id, id), eq(equipment.isActive, true))).returning();
    if (!deactivated) throw new HttpError(404, "Active equipment was not found");
    return deactivated;
  });
}

export async function listTickets(filters?: { status?: string; creatorId?: string }) {
  await bootstrap;
  const conditions = [];
  if (filters?.status) conditions.push(eq(tickets.status, filters.status as Ticket["status"]));
  if (filters?.creatorId) conditions.push(eq(tickets.creatorId, filters.creatorId));
  const query = db.select({ ticket: tickets, equipment: equipment }).from(tickets).leftJoin(equipment, eq(tickets.equipmentId, equipment.id)).orderBy(desc(tickets.updatedAt));
  return conditions.length ? query.where(and(...conditions)) : query;
}

export async function getTicket(ticketNumber: number, user?: AppUser) {
  await bootstrap;
  const [row] = await db.select({ ticket: tickets, equipment: equipment }).from(tickets).leftJoin(equipment, eq(tickets.equipmentId, equipment.id)).where(eq(tickets.ticketNumber, ticketNumber)).limit(1);
  if (!row) throw new HttpError(404, "Ticket not found");
  if (user && can(user.roles, "add_ticket_note") && !canUpdateAllTickets(user.roles) && row.ticket.creatorId !== user.id) throw new HttpError(404, "Ticket not found");
  const history = await db.select().from(ticketHistory).where(eq(ticketHistory.ticketNumber, ticketNumber)).orderBy(desc(ticketHistory.createdAt));
  const alerts = await db.select().from(notifications).where(eq(notifications.ticketNumber, ticketNumber)).orderBy(desc(notifications.createdAt));
  return { ...row, history, notifications: alerts };
}

export async function createTicket(input: z.infer<typeof ticketCreateSchema>, user: AppUser) {
  await bootstrap;
  const ticket = await db.transaction(async (tx) => {
    const next = await tx.execute(sql`select coalesce(max(ticket_number), 999999) + 1 as ticket_number from ${tickets}`);
    const ticketNumber = Number(rowsOf<{ ticket_number: number | string }>(next)[0]?.ticket_number);
    if (!Number.isInteger(ticketNumber) || ticketNumber > 9999999) throw new HttpError(409, "Ticket number range exhausted");
    if (input.equipmentId) {
      const [selectedEquipment] = await tx.select({ id: equipment.id }).from(equipment).where(and(eq(equipment.id, input.equipmentId), eq(equipment.isActive, true))).limit(1);
      if (!selectedEquipment) throw new HttpError(400, "Select an active registered equipment record");
    }
    const [createdTicket] = await tx.insert(tickets).values({ ticketNumber, ...input, creatorId: user.id, creatorName: user.displayName, creatorEmail: user.email ?? null }).returning();
    await tx.insert(ticketHistory).values({ ticketNumber, actorId: user.id, actorName: user.displayName, action: "created", toStatus: "new", note: "Ticket created." });
    return createdTicket;
  });
  await recordDeliveries(deliveryRecords(user.id, ticket.ticketNumber, "ticket_created", `Ticket ${ticket.ticketNumber} created`, "Your LabCare support ticket was received."));
  return ticket;
}

function canUpdateAllTickets(roles: readonly string[]) {
  return hasAnyRole(roles, ["admin", "support_team"]);
}

const transitions: Record<Ticket["status"], Ticket["status"][]> = {
  new: ["triaged", "closed"], triaged: ["in_progress", "waiting_on_customer", "closed"], in_progress: ["waiting_on_customer", "resolved", "closed"], waiting_on_customer: ["in_progress", "closed"], resolved: ["closed", "in_progress"], closed: [],
};

export async function updateTicket(ticketNumber: number, input: z.infer<typeof ticketUpdateSchema>, user: AppUser) {
  await bootstrap;
  if (!can(user.roles, "update_ticket") && !can(user.roles, "add_ticket_note")) {
    throw new HttpError(403, "Ticket updates are not permitted");
  }
  if (!can(user.roles, "update_ticket")) {
    const keys = Object.keys(input);
    if (keys.some((key) => key !== "note") || !input.note) {
      throw new HttpError(403, "Customers may only add a note to their own tickets");
    }
  }
  const result = await db.transaction(async (tx) => {
    const [current] = await tx.select().from(tickets).where(eq(tickets.ticketNumber, ticketNumber)).limit(1);
    if (!current) throw new HttpError(404, "Ticket not found");
    if (!canUpdateAllTickets(user.roles) && current.creatorId !== user.id) throw new HttpError(403, "Customers may only update tickets they created");
    const statusChanged = Boolean(input.status && input.status !== current.status);
    if (statusChanged && !transitions[current.status].includes(input.status!)) throw new HttpError(409, `Cannot move ticket from ${current.status} to ${input.status}`);
    const { note, status, ...fields } = input;
    const fieldChanged = Object.entries(fields).some(([key, value]) => value !== current[key as keyof Ticket]);
    const [updated] = await tx.update(tickets).set({ ...fields, ...(status ? { status, ...(status === "resolved" ? { resolvedAt: new Date() } : {}) } : {}) }).where(eq(tickets.ticketNumber, ticketNumber)).returning();
    if (statusChanged || note) await tx.insert(ticketHistory).values({ ticketNumber, actorId: user.id, actorName: user.displayName, action: statusChanged ? "status_changed" : "note_added", fromStatus: current.status, toStatus: statusChanged ? status : current.status, note: note ?? null });
    const materiallyUpdated = statusChanged || fieldChanged || Boolean(note);
    const message = statusChanged ? `Status changed to ${status!.replaceAll("_", " ")}.` : note ? "A note was added to this ticket." : "Ticket details were updated.";
    return { updated, materiallyUpdated, message };
  });
  if (result.materiallyUpdated) await recordDeliveries(deliveryRecords(result.updated.creatorId, ticketNumber, "ticket_update", `Ticket ${ticketNumber} updated`, result.message));
  return result.updated;
}

export async function listNotifications(userId: string, unreadOnly = false) {
  await bootstrap;
  const condition = unreadOnly ? and(eq(notifications.recipientUserId, userId), sql`${notifications.readAt} is null`) : eq(notifications.recipientUserId, userId);
  return db.select().from(notifications).where(condition).orderBy(desc(notifications.createdAt));
}

export async function markNotificationRead(id: string, userId: string) {
  await bootstrap;
  const [updated] = await db.update(notifications).set({ readAt: new Date() }).where(and(eq(notifications.id, id), eq(notifications.recipientUserId, userId))).returning();
  if (!updated) throw new HttpError(404, "Notification not found");
  return updated;
}
