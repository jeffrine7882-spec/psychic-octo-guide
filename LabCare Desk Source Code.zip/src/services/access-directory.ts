import { and, desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { accessDirectory, accessInvitations, insertAccessDirectorySchema, insertAccessInvitationSchema } from "@/db/schema";
import { bootstrapModule, type RuntimeTableBootstrap } from "@/services/bootstrap";
import { seedTimestamp } from "@/services/seed-utils";
import { HttpError } from "@/lib/route-handlers";
import { z } from "zod";

const directoryBootstrap: RuntimeTableBootstrap[] = [
  {
    table: accessDirectory,
    prepare: [sql`do $$ begin create type directory_status as enum ('active', 'deactivated'); exception when duplicate_object then null; end $$`, sql`alter table if exists access_directory add column if not exists phone text not null default ''`],
    createTable: sql`create table if not exists access_directory (id text primary key, user_id text not null unique, display_name text not null, email text, phone text not null, role_key text not null, status directory_status not null default 'active', deactivated_at timestamp, created_at timestamp not null default now(), updated_at timestamp not null default now())`,
    createIndexes: [sql`create index if not exists access_directory_status_idx on access_directory(status)`, sql`create index if not exists access_directory_email_idx on access_directory(email)`],
    seed: async (tx) => {
      await tx.insert(accessDirectory).values([
        { id: "directory-maya", userId: "maya.chen", displayName: "Maya Chen", email: "maya.chen@labcare.example", phone: "+1 (415) 555-0138", roleKey: "customer", status: "active", createdAt: seedTimestamp(-30), updatedAt: seedTimestamp(-2) },
        { id: "directory-lee", userId: "support-lee", displayName: "Lee Wong", email: "lee.wong@labcare.example", phone: "+1 415-555-0172", roleKey: "support_team", status: "active", createdAt: seedTimestamp(-30), updatedAt: seedTimestamp(-2) },
        { id: "directory-rina", userId: "support-rina", displayName: "Rina Das", email: "rina.das@labcare.example", phone: "+1 415 555 0196", roleKey: "support_team", status: "active", createdAt: seedTimestamp(-28), updatedAt: seedTimestamp(-2) },
        { id: "directory-oliver", userId: "oliver.grant", displayName: "Oliver Grant", email: "oliver.grant@labcare.example", phone: "+44 (20) 7946-0958", roleKey: "customer", status: "active", createdAt: seedTimestamp(-20), updatedAt: seedTimestamp(-1) },
      ]).onConflictDoNothing();
    },
  },
  {
    table: accessInvitations,
    prepare: [sql`do $$ begin create type invitation_status as enum ('pending', 'revoked'); exception when duplicate_object then null; end $$`],
    createTable: sql`create table if not exists access_invitations (id text primary key, email text not null, display_name text not null, phone text not null, role_key text not null, status invitation_status not null default 'pending', invited_by_id text not null, invited_by_name text not null, revoked_at timestamp, created_at timestamp not null default now(), updated_at timestamp not null default now())`,
    createIndexes: [sql`create index if not exists access_invitations_status_idx on access_invitations(status)`, sql`create index if not exists access_invitations_email_idx on access_invitations(email)`],
  },
];
const bootstrap = bootstrapModule("labcare-access-directory", directoryBootstrap);

const phoneSchema = z.string().trim().min(1).refine((value) => /^\+?[0-9 ()-]+$/.test(value) && (value.match(/[0-9]/g)?.length ?? 0) >= 7 && (value.match(/[0-9]/g)?.length ?? 0) <= 20, "Enter a valid phone number with 7–20 digits.");
const roleSchema = z.enum(["support_team", "customer", "viewer"]);

export const accessEntrySchema = insertAccessDirectorySchema.pick({ userId: true, displayName: true, email: true, phone: true, roleKey: true }).extend({
  userId: z.string().trim().min(1).max(200),
  displayName: z.string().trim().min(1).max(200),
  email: z.string().email(),
  phone: phoneSchema,
  roleKey: roleSchema,
});

export const accessInvitationSchema = insertAccessInvitationSchema.pick({ email: true, displayName: true, phone: true, roleKey: true }).extend({
  email: z.string().trim().email("Enter a valid email address.").transform((value) => value.toLowerCase()),
  displayName: z.string().trim().min(1, "Display name is required.").max(200),
  phone: phoneSchema,
  roleKey: roleSchema,
});

export async function listAccessDirectory(includeDeactivated = false) {
  await bootstrap;
  return db.select().from(accessDirectory).where(includeDeactivated ? undefined : eq(accessDirectory.status, "active")).orderBy(desc(accessDirectory.createdAt));
}

export async function listAccessInvitations() {
  await bootstrap;
  return db.select().from(accessInvitations).orderBy(desc(accessInvitations.createdAt));
}

export async function addAccessEntry(input: z.infer<typeof accessEntrySchema>) {
  await bootstrap;
  const [existing] = await db.select().from(accessDirectory).where(eq(accessDirectory.userId, input.userId)).limit(1);
  if (existing) throw new HttpError(409, "User already exists in the access directory");
  const [emailMatch] = await db.select().from(accessDirectory).where(sql`lower(${accessDirectory.email}) = ${input.email.toLowerCase()}`).limit(1);
  if (emailMatch) throw new HttpError(409, "Email already exists in the access directory");
  const [entry] = await db.insert(accessDirectory).values({ ...input, email: input.email.toLowerCase() }).returning();
  return entry;
}

export async function createAccessInvitation(input: z.infer<typeof accessInvitationSchema>, actor: { id: string; displayName: string }) {
  await bootstrap;
  const email = input.email.toLowerCase();
  return db.transaction(async (tx) => {
    const [directoryMatch] = await tx.select().from(accessDirectory).where(sql`lower(${accessDirectory.email}) = ${email}`).limit(1);
    if (directoryMatch) throw new HttpError(409, "Email already exists in the access directory");
    const [pendingMatch] = await tx.select().from(accessInvitations).where(and(eq(accessInvitations.email, email), eq(accessInvitations.status, "pending"))).limit(1);
    if (pendingMatch) throw new HttpError(409, "A pending invitation already exists for this email");
    const [invitation] = await tx.insert(accessInvitations).values({ ...input, email, status: "pending", invitedById: actor.id, invitedByName: actor.displayName }).returning();
    return invitation;
  });
}

export async function revokeAccessInvitation(id: string) {
  await bootstrap;
  const [invitation] = await db.update(accessInvitations).set({ status: "revoked", revokedAt: new Date() }).where(and(eq(accessInvitations.id, id), eq(accessInvitations.status, "pending"))).returning();
  if (!invitation) throw new HttpError(404, "Pending invitation not found");
  return invitation;
}

export async function deactivateAccessEntry(id: string) {
  await bootstrap;
  const [entry] = await db.update(accessDirectory).set({ status: "deactivated", deactivatedAt: new Date() }).where(and(eq(accessDirectory.id, id), eq(accessDirectory.status, "active"))).returning();
  if (!entry) throw new HttpError(404, "Active access entry not found");
  return entry;
}
