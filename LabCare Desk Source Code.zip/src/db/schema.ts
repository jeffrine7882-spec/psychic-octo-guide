import { randomUUID } from "node:crypto";
import { pgEnum, pgSchema, pgTable, text, integer, boolean, timestamp, type PgSchema } from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema, createUpdateSchema } from "drizzle-zod";

/** The application schema; every declaration must be bound to it. */
type AppSchema = Pick<PgSchema<string>, "table" | "enum">;
const dbSchemaName = process.env.DB_SCHEMA?.trim();
export const appSchema: AppSchema = dbSchemaName
  ? pgSchema(dbSchemaName)
  : ({ table: pgTable, enum: pgEnum } as unknown as AppSchema);

export const timestamps = {
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at")
    .defaultNow()
    .notNull()
    .$onUpdateFn(() => new Date()),
};

export const ticketType = appSchema.enum("ticket_type", ["complaint", "breakdown"]);
export const ticketStatus = appSchema.enum("ticket_status", [
  "new",
  "triaged",
  "in_progress",
  "waiting_on_customer",
  "resolved",
  "closed",
]);
export const ticketPriority = appSchema.enum("ticket_priority", ["low", "normal", "high", "urgent"]);
export const notificationChannel = appSchema.enum("notification_channel", ["in_app", "email", "phone"]);
export const notificationDeliveryStatus = appSchema.enum("notification_delivery_status", ["delivered", "not_configured"]);
export const directoryStatus = appSchema.enum("directory_status", ["active", "deactivated"]);
export const invitationStatus = appSchema.enum("invitation_status", ["pending", "revoked"]);

export const equipment = appSchema.table("equipment", {
  id: text("id").primaryKey().$defaultFn(() => randomUUID()),
  assetTag: text("asset_tag").notNull().unique(),
  name: text("name").notNull(),
  manufacturer: text("manufacturer"),
  model: text("model"),
  location: text("location"),
  serialNumber: text("serial_number"),
  isActive: boolean("is_active").default(true).notNull(),
  ...timestamps,
});

export const accessDirectory = appSchema.table("access_directory", {
  id: text("id").primaryKey().$defaultFn(() => randomUUID()),
  userId: text("user_id").notNull().unique(),
  displayName: text("display_name").notNull(),
  email: text("email"),
  phone: text("phone").notNull(),
  roleKey: text("role_key").notNull(),
  status: directoryStatus("status").default("active").notNull(),
  deactivatedAt: timestamp("deactivated_at"),
  ...timestamps,
});

export const accessInvitations = appSchema.table("access_invitations", {
  id: text("id").primaryKey().$defaultFn(() => randomUUID()),
  email: text("email").notNull(),
  displayName: text("display_name").notNull(),
  phone: text("phone").notNull(),
  roleKey: text("role_key").notNull(),
  status: invitationStatus("status").default("pending").notNull(),
  invitedById: text("invited_by_id").notNull(),
  invitedByName: text("invited_by_name").notNull(),
  revokedAt: timestamp("revoked_at"),
  ...timestamps,
});

export const tickets = appSchema.table("tickets", {
  ticketNumber: integer("ticket_number").primaryKey(),
  type: ticketType("type").notNull(),
  status: ticketStatus("status").default("new").notNull(),
  priority: ticketPriority("priority").default("normal").notNull(),
  subject: text("subject").notNull(),
  description: text("description").notNull(),
  equipmentId: text("equipment_id").references(() => equipment.id),
  creatorId: text("creator_id").notNull(),
  creatorName: text("creator_name").notNull(),
  creatorEmail: text("creator_email"),
  assignedTo: text("assigned_to"),
  resolution: text("resolution"),
  resolvedAt: timestamp("resolved_at"),
  ...timestamps,
});

export const ticketHistory = appSchema.table("ticket_history", {
  id: text("id").primaryKey().$defaultFn(() => randomUUID()),
  ticketNumber: integer("ticket_number").notNull().references(() => tickets.ticketNumber),
  actorId: text("actor_id").notNull(),
  actorName: text("actor_name").notNull(),
  action: text("action").notNull(),
  fromStatus: ticketStatus("from_status"),
  toStatus: ticketStatus("to_status"),
  note: text("note"),
  ...timestamps,
});

export const notifications = appSchema.table("notifications", {
  id: text("id").primaryKey().$defaultFn(() => randomUUID()),
  recipientUserId: text("recipient_user_id").notNull(),
  ticketNumber: integer("ticket_number").references(() => tickets.ticketNumber),
  kind: text("kind").notNull(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  channel: notificationChannel("channel").default("in_app").notNull(),
  deliveryStatus: notificationDeliveryStatus("delivery_status").default("delivered").notNull(),
  readAt: timestamp("read_at"),
  ...timestamps,
});

export const insertEquipmentSchema = createInsertSchema(equipment);
export const selectEquipmentSchema = createSelectSchema(equipment);
export const updateEquipmentSchema = createUpdateSchema(equipment);
export const insertAccessDirectorySchema = createInsertSchema(accessDirectory);
export const selectAccessDirectorySchema = createSelectSchema(accessDirectory);
export const updateAccessDirectorySchema = createUpdateSchema(accessDirectory);
export const insertAccessInvitationSchema = createInsertSchema(accessInvitations);
export const selectAccessInvitationSchema = createSelectSchema(accessInvitations);
export const updateAccessInvitationSchema = createUpdateSchema(accessInvitations);
export const insertTicketSchema = createInsertSchema(tickets);
export const selectTicketSchema = createSelectSchema(tickets);
export const updateTicketSchema = createUpdateSchema(tickets);
export const insertTicketHistorySchema = createInsertSchema(ticketHistory);
export const selectTicketHistorySchema = createSelectSchema(ticketHistory);
export const insertNotificationSchema = createInsertSchema(notifications);
export const selectNotificationSchema = createSelectSchema(notifications);

export type NotificationChannel = (typeof notificationChannel.enumValues)[number];
export type NotificationDeliveryStatus = (typeof notificationDeliveryStatus.enumValues)[number];
export type Equipment = typeof equipment.$inferSelect;
export type AccessDirectoryEntry = typeof accessDirectory.$inferSelect;
export type AccessInvitation = typeof accessInvitations.$inferSelect;
export type Ticket = typeof tickets.$inferSelect;
export type TicketHistory = typeof ticketHistory.$inferSelect;
export type Notification = typeof notifications.$inferSelect;
export type NewTicket = typeof tickets.$inferInsert;
export type NewAccessDirectoryEntry = typeof accessDirectory.$inferInsert;
export type NewAccessInvitation = typeof accessInvitations.$inferInsert;
