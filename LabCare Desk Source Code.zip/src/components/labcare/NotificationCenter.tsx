"use client";

import { Bell, Check, Mail, Phone } from "lucide-react";
import { toast } from "sonner";
import { apiUrl } from "@/lib/utils";
import { useRequest } from "@/lib/hooks";
import { can } from "@/lib/permissions";
import type { AppUser } from "@/lib/users";
import { markLabCareNotificationRead, requireLabCareResponse } from "@/lib/labcare-api";
import { AsyncView } from "@/components/data/async-view";
import { Button, Card, PageHeader, StatusBadge } from "@/components/ui";
import { formatDate, notificationChannelLabels, notificationDeliveryStatusLabels } from "./types";
import type { Notification } from "@/db/schema";

async function loadNotifications(signal: AbortSignal) {
  const response = await fetch(apiUrl("/api/notifications"), { signal, cache: "no-store" });
  return await requireLabCareResponse(response) as Notification[];
}

const channelIcons = { in_app: Bell, email: Mail, phone: Phone };

export function NotificationCenter({ user }: { user?: AppUser }) {
  const request = useRequest("labcare-notifications", loadNotifications);
  if (!user || !can(user.roles, "view_notifications")) return null;

  async function markRead(id: string) {
    try {
      await requireLabCareResponse(await markLabCareNotificationRead(id));
      toast.success("Notification marked as read");
      request.refresh();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Unable to update notification");
    }
  }

  return <main className="min-h-full bg-background px-4 py-6 sm:px-6 lg:px-8"><div className="mx-auto max-w-4xl space-y-6"><PageHeader eyebrow="LabCare Desk" title="Notifications" /><Card title="Recent updates"><AsyncView result={request} isEmpty={(items) => items.length === 0} empty={<p className="p-8 text-center text-sm text-muted-foreground">No notifications to review.</p>}>{(items) => <div className="divide-y divide-border">{items.map((item) => {
    const Icon = channelIcons[item.channel];
    return <div key={item.id} className="flex gap-3 p-4"><Icon className="mt-0.5 size-4 shrink-0 text-accent-strong" /><div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2"><p className="font-medium">{item.title}</p><StatusBadge status={item.deliveryStatus}>{notificationChannelLabels[item.channel]} · {notificationDeliveryStatusLabels[item.deliveryStatus]}</StatusBadge>{item.channel === "in_app" && !item.readAt && <StatusBadge status="new">New</StatusBadge>}</div><p className="mt-1 text-sm text-muted-foreground">{item.message}</p><p className="mt-1 text-xs text-muted-foreground">{formatDate(item.createdAt)}</p></div>{item.channel === "in_app" && !item.readAt && can(user.roles, "update_notifications") && <Button variant="ghost" size="sm" onClick={() => void markRead(item.id)}><Check className="size-4" />Read</Button>}</div>;
  })}</div>}</AsyncView></Card></div></main>;
}
