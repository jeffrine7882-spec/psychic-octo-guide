"use client";

import { useMemo, useState, type FormEvent } from "react";
import { Archive, Plus, RefreshCw, Search } from "lucide-react";
import { toast } from "sonner";
import { AsyncView } from "@/components/data/async-view";
import { FieldGroup, FormGrid } from "@/components/forms/form-layout";
import { ConfirmDialog } from "@/components/overlays/confirm-dialog";
import { FormDialog } from "@/components/overlays/form-dialog";
import { Button, Card, PageHeader, StatusBadge } from "@/components/ui";
import type { Equipment } from "@/db/schema";
import { useRequest } from "@/lib/hooks";
import { addLabCareEquipment, deactivateLabCareEquipment, requireLabCareResponse } from "@/lib/labcare-api";
import { can } from "@/lib/permissions";
import type { AppUser } from "@/lib/users";
import { apiUrl } from "@/lib/utils";
import { formatDate } from "./types";

async function loadEquipment(signal: AbortSignal) {
  const response = await fetch(apiUrl("/api/equipment"), { signal, cache: "no-store" });
  return await requireLabCareResponse(response) as Equipment[];
}

export function EquipmentRegistry({ user }: { user?: AppUser }) {
  const request = useRequest("labcare-equipment", loadEquipment);
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const [archiveTarget, setArchiveTarget] = useState<Equipment | null>(null);
  const [pending, setPending] = useState(false);
  const canManage = Boolean(user && can(user.roles, "manage_equipment"));
  const equipment = request.data;
  const visibleEquipment = useMemo(() => {
    const records = equipment ?? [];
    const term = search.trim().toLowerCase();
    if (!term) return records;
    return records.filter((item) => [item.assetTag, item.name, item.manufacturer, item.model, item.serialNumber, item.location].some((value) => value?.toLowerCase().includes(term)));
  }, [equipment, search]);

  async function addEquipment(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setPending(true);
    const form = new FormData(event.currentTarget);
    const raw = Object.fromEntries(form.entries());
    const payload = {
      ...raw,
      manufacturer: raw.manufacturer || null,
      model: raw.model || null,
      serialNumber: raw.serialNumber || null,
    };
    try {
      await requireLabCareResponse(await addLabCareEquipment(payload));
      toast.success("Equipment registered");
      setOpen(false);
      request.refresh();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Unable to register equipment");
    } finally {
      setPending(false);
    }
  }

  async function archiveEquipment() {
    if (!archiveTarget) return;
    setPending(true);
    try {
      await requireLabCareResponse(await deactivateLabCareEquipment(archiveTarget.id));
      toast.success("Equipment archived");
      setArchiveTarget(null);
      request.refresh();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Unable to archive equipment");
    } finally {
      setPending(false);
    }
  }

  return <main className="min-h-full bg-background px-4 py-6 sm:px-6 lg:px-8"><div className="mx-auto max-w-7xl space-y-6">
    <PageHeader eyebrow="LabCare Desk" title="Equipment registry" actions={canManage ? <Button variant="highlight" onClick={() => setOpen(true)}><Plus className="size-4" />Add equipment</Button> : undefined} />
    <Card flush title="Registered equipment" actions={<div className="flex flex-wrap items-center justify-end gap-2"><div className="relative w-full max-w-xs"><Search className="pointer-events-none absolute left-2.5 top-2.5 size-4 text-muted-foreground" /><input aria-label="Search equipment" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search equipment" className="h-9 w-full rounded-md border border-border bg-card pl-9 pr-3 text-sm outline-none focus:ring-2 focus:ring-ring" /></div><Button variant="ghost" size="sm" onClick={request.refresh}><RefreshCw className="size-4" />Refresh</Button></div>}>
      <AsyncView result={request} isEmpty={() => visibleEquipment.length === 0} empty={<p className="p-10 text-center text-sm text-muted-foreground">No equipment matches the current view.</p>}>{() => <><div className="hidden overflow-x-auto md:block"><table className="w-full min-w-[900px] text-left text-sm"><thead className="bg-surface-inset text-xs uppercase tracking-wide text-muted-foreground"><tr><th className="px-4 py-3">Equipment</th><th className="px-4 py-3">Asset tag</th><th className="px-4 py-3">Manufacturer / model</th><th className="px-4 py-3">Serial number</th><th className="px-4 py-3">Site</th><th className="px-4 py-3">Status</th>{canManage && <th className="px-4 py-3" />}</tr></thead><tbody className="divide-y divide-border">{visibleEquipment.map((item) => <tr key={item.id} className="hover:bg-surface-inset/60"><td className="px-4 py-3 font-medium">{item.name}<div className="text-xs font-normal text-muted-foreground">Added {formatDate(item.createdAt)}</div></td><td className="px-4 py-3 font-mono text-xs">{item.assetTag}</td><td className="px-4 py-3 text-muted-foreground">{[item.manufacturer, item.model].filter(Boolean).join(" · ") || "—"}</td><td className="px-4 py-3 text-muted-foreground">{item.serialNumber ?? "—"}</td><td className="px-4 py-3 text-muted-foreground">{item.location ?? "—"}</td><td className="px-4 py-3"><StatusBadge status={item.isActive ? "active" : "deactivated"}>{item.isActive ? "Active" : "Archived"}</StatusBadge></td>{canManage && <td className="px-4 py-3 text-right">{item.isActive && <Button variant="ghost" size="sm" onClick={() => setArchiveTarget(item)}><Archive className="size-4" />Archive</Button>}</td>}</tr>)}</tbody></table></div><div className="divide-y divide-border md:hidden">{visibleEquipment.map((item) => <article key={item.id} className="space-y-2 p-4"><div className="flex items-start justify-between gap-3"><div><p className="font-medium">{item.name}</p><p className="mt-1 font-mono text-xs text-muted-foreground">{item.assetTag}</p></div><StatusBadge status={item.isActive ? "active" : "deactivated"}>{item.isActive ? "Active" : "Archived"}</StatusBadge></div><p className="text-sm text-muted-foreground">{[item.manufacturer, item.model].filter(Boolean).join(" · ") || "Manufacturer and model not recorded"}</p><div className="flex flex-wrap items-center justify-between gap-2 text-xs text-muted-foreground"><span>{item.location ?? "Site not recorded"}</span>{canManage && item.isActive && <Button variant="ghost" size="sm" onClick={() => setArchiveTarget(item)}><Archive className="size-4" />Archive</Button>}</div></article>)}</div></>}</AsyncView>
    </Card>
    <FormDialog open={open} onOpenChange={setOpen} title="Add equipment" description="Register the instrument and site details used when opening service tickets." size="lg" submitLabel="Register equipment" pending={pending} onSubmit={addEquipment}><FormGrid><FieldGroup label="Equipment name" htmlFor="equipment-name" required><input id="equipment-name" name="name" required minLength={2} maxLength={200} className="field-control" /></FieldGroup><FieldGroup label="Asset tag" htmlFor="asset-tag" required><input id="asset-tag" name="assetTag" required minLength={2} maxLength={100} className="field-control" /></FieldGroup><FieldGroup label="Manufacturer" htmlFor="manufacturer"><input id="manufacturer" name="manufacturer" maxLength={200} className="field-control" /></FieldGroup><FieldGroup label="Model" htmlFor="model"><input id="model" name="model" maxLength={200} className="field-control" /></FieldGroup><FieldGroup label="Serial number" htmlFor="serial-number"><input id="serial-number" name="serialNumber" maxLength={200} className="field-control" /></FieldGroup><FieldGroup label="Location / site" htmlFor="location" required><input id="location" name="location" required minLength={2} maxLength={200} className="field-control" /></FieldGroup></FormGrid></FormDialog>
    <ConfirmDialog open={archiveTarget !== null} onOpenChange={(nextOpen) => { if (!nextOpen) setArchiveTarget(null); }} title="Archive equipment" description={archiveTarget ? `Archive ${archiveTarget.assetTag}? It will remain on historical tickets but cannot be selected for new tickets.` : ""} confirmLabel="Archive equipment" destructive pending={pending} onConfirm={archiveEquipment} />
  </div></main>;
}
