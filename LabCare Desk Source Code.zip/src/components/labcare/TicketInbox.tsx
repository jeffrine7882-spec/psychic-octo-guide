"use client";
import { useMemo, useState, type FormEvent } from "react";
import { Link } from "@tanstack/react-router";
import { Plus, Search, RefreshCw, Ticket as TicketIcon } from "lucide-react";
import { toast } from "sonner";
import { apiUrl } from "@/lib/utils";
import { useRequest } from "@/lib/hooks";
import { can } from "@/lib/permissions";
import type { AppUser } from "@/lib/users";
import type { Equipment } from "@/db/schema";
import { createLabCareTicket, requireLabCareResponse } from "@/lib/labcare-api";
import { AsyncView } from "@/components/data/async-view";
import { FormDialog } from "@/components/overlays/form-dialog";
import { FieldGroup, FormGrid } from "@/components/forms/form-layout";
import { Button, Card, PageHeader, StatCard, StatusBadge } from "@/components/ui";
import { formatDate, priorityLabels, statuses, statusLabels, typeLabels, type TicketRow } from "./types";

async function loadTickets(signal: AbortSignal) {
  const response = await fetch(apiUrl("/api/tickets"), { signal, cache: "no-store" });
  return await requireLabCareResponse(response) as TicketRow[];
}
async function loadActiveEquipment(signal: AbortSignal) {
  const response = await fetch(apiUrl("/api/equipment"), { signal, cache: "no-store" });
  return await requireLabCareResponse(response) as Equipment[];
}
function labelStatus(status: string) { return statusLabels[status as keyof typeof statusLabels] ?? status; }

const EMPTY_TICKETS: TicketRow[] = [];

export function TicketInbox({ user }: { user?: AppUser }) {
  const contextUser = user;
  const [status, setStatus] = useState<string>("all");
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const request = useRequest("labcare-tickets", loadTickets);
  const equipmentRequest = useRequest("labcare-active-equipment", loadActiveEquipment);
  const tickets = request.data ?? EMPTY_TICKETS;
  const activeEquipment = equipmentRequest.data ?? [];
  const filtered = useMemo(() => tickets.filter(({ ticket }) => (status === "all" || ticket.status === status) && `${ticket.ticketNumber} ${ticket.subject} ${ticket.creatorName}`.toLowerCase().includes(search.toLowerCase())), [tickets, status, search]);
  const counts = useMemo(() => statuses.reduce((all, item) => ({ ...all, [item]: tickets.filter(({ ticket }) => ticket.status === item).length }), {} as Record<string, number>), [tickets]);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const payload = Object.fromEntries(form.entries());
    try { await requireLabCareResponse(await createLabCareTicket({ ...payload, equipmentId: payload.equipmentId || null })); toast.success("Ticket created"); setOpen(false); request.refresh(); }
    catch (error) { toast.error(error instanceof Error ? error.message : "Unable to create ticket"); }
  }
  if (!contextUser) return null;
  return <main className="min-h-full bg-background px-4 py-6 sm:px-6 lg:px-8"><div className="mx-auto max-w-7xl space-y-6">
    <PageHeader eyebrow="LabCare Desk" title="Ticket inbox" actions={can(contextUser.roles, "create_ticket") ? <Button variant="highlight" onClick={() => setOpen(true)}><Plus className="size-4" />New ticket</Button> : undefined} />
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-4"><StatCard label="All tickets" value={tickets.length} icon={<TicketIcon />} tone="info" /><StatCard label="New" value={counts.new ?? 0} icon={<RefreshCw />} /><StatCard label="In progress" value={counts.in_progress ?? 0} icon={<RefreshCw />} tone="running" /><StatCard label="Waiting" value={counts.waiting_on_customer ?? 0} icon={<RefreshCw />} tone="paused" /></div>
    <Card flush title="Support queue" actions={<div className="flex flex-wrap items-center justify-end gap-2"><div className="relative w-full max-w-xs"><Search className="pointer-events-none absolute left-2.5 top-2.5 size-4 text-muted-foreground" /><input aria-label="Search tickets" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search tickets" className="h-9 w-full rounded-md border border-border bg-card pl-9 pr-3 text-sm outline-none focus:ring-2 focus:ring-ring" /></div><Button variant="ghost" size="sm" onClick={request.refresh}><RefreshCw className="size-4" />Refresh</Button></div>}>
      <div className="flex gap-1 overflow-x-auto border-b border-border px-4 py-3">{[{ key: "all", label: "All", count: tickets.length }, ...statuses.map((item) => ({ key: item, label: labelStatus(item), count: counts[item] ?? 0 }))].map((item) => <button type="button" key={item.key} onClick={() => setStatus(item.key)} className={`whitespace-nowrap rounded-md px-3 py-1.5 text-xs font-medium ${status === item.key ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-surface-inset"}`}>{item.label} <span className="ml-1 opacity-70">{item.count}</span></button>)}</div>
      <AsyncView result={request} isEmpty={() => filtered.length === 0} empty={<div className="p-10 text-center text-sm text-muted-foreground">No tickets match the current view.</div>}>{() => <><div className="hidden overflow-x-auto md:block"><table className="w-full min-w-[760px] text-left text-sm"><thead className="bg-surface-inset text-xs uppercase tracking-wide text-muted-foreground"><tr><th className="px-4 py-3">Ticket</th><th className="px-4 py-3">Subject</th><th className="px-4 py-3">Status</th><th className="px-4 py-3">Priority</th><th className="px-4 py-3">Equipment</th><th className="px-4 py-3">Updated</th></tr></thead><tbody className="divide-y divide-border">{filtered.map(({ ticket, equipment }) => <tr key={ticket.ticketNumber} className="hover:bg-surface-inset/60"><td className="px-4 py-3 font-mono"><Link className="font-semibold text-accent-strong hover:underline" to="/tickets/$ticketNumber" params={{ ticketNumber: String(ticket.ticketNumber) }}>{ticket.ticketNumber}</Link></td><td className="max-w-[260px] truncate px-4 py-3 font-medium">{ticket.subject}<div className="text-xs font-normal text-muted-foreground">{ticket.creatorName}</div></td><td className="px-4 py-3"><StatusBadge status={ticket.status}>{statusLabels[ticket.status]}</StatusBadge></td><td className="px-4 py-3">{priorityLabels[ticket.priority]}</td><td className="px-4 py-3 text-muted-foreground">{equipment?.assetTag ?? "—"}</td><td className="px-4 py-3 text-xs text-muted-foreground">{formatDate(ticket.updatedAt)}</td></tr>)}</tbody></table></div><div className="divide-y divide-border md:hidden">{filtered.map(({ ticket, equipment }) => <Link key={ticket.ticketNumber} to="/tickets/$ticketNumber" params={{ ticketNumber: String(ticket.ticketNumber) }} className="block space-y-2 p-4 hover:bg-surface-inset"><div className="flex items-center justify-between"><span className="font-mono text-xs font-semibold text-accent-strong">#{ticket.ticketNumber}</span><StatusBadge status={ticket.status}>{statusLabels[ticket.status]}</StatusBadge></div><p className="font-medium">{ticket.subject}</p><p className="text-xs text-muted-foreground">{typeLabels[ticket.type]} · {priorityLabels[ticket.priority]} · {equipment?.assetTag ?? "No equipment"}</p></Link>)}</div></>}</AsyncView>
    </Card>
    <FormDialog open={open} onOpenChange={setOpen} title="New support ticket" description="Describe the laboratory equipment issue so support can triage it." size="lg" submitLabel="Create ticket" onSubmit={submit}><FormGrid><FieldGroup label="Type" htmlFor="type" required><select id="type" name="type" required defaultValue="complaint" className="field-control"><option value="complaint">Complaint</option><option value="breakdown">Breakdown</option></select></FieldGroup><FieldGroup label="Priority" htmlFor="priority"><select id="priority" name="priority" className="field-control"><option value="low">Low</option><option value="normal">Normal</option><option value="high">High</option><option value="urgent">Urgent</option></select></FieldGroup></FormGrid><FieldGroup label="Subject" htmlFor="subject" required><input id="subject" name="subject" required minLength={3} maxLength={200} className="field-control" /></FieldGroup><FieldGroup label="Equipment" htmlFor="equipmentId" helperText="Select the affected active asset when known."><select id="equipmentId" name="equipmentId" className="field-control"><option value="">Not specified</option>{activeEquipment.map((item) => <option key={item.id} value={item.id}>{item.assetTag} · {item.name}</option>)}</select></FieldGroup><FieldGroup label="Description" htmlFor="description" required><textarea id="description" name="description" required minLength={5} rows={5} maxLength={5000} className="field-control resize-y" /></FieldGroup></FormDialog>
  </div></main>;
}
