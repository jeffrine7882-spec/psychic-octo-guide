"use client";

import { useState, type FormEvent } from "react";
import { Ban, Mail, UserPlus, UserX } from "lucide-react";
import { toast } from "sonner";
import { apiUrl } from "@/lib/utils";
import { useRequest } from "@/lib/hooks";
import { can } from "@/lib/permissions";
import type { AppUser } from "@/lib/users";
import { addLabCareAccessEntry, deactivateLabCareAccessEntry, inviteLabCareUser, requireLabCareResponse, revokeLabCareInvitation } from "@/lib/labcare-api";
import { AsyncView } from "@/components/data/async-view";
import { ConfirmDialog } from "@/components/overlays/confirm-dialog";
import { FormDialog } from "@/components/overlays/form-dialog";
import { FieldGroup, FormGrid } from "@/components/forms/form-layout";
import { Button, Card, PageHeader, StatusBadge } from "@/components/ui";
import type { AccessDirectoryEntry, AccessInvitation } from "@/db/schema";

type DirectoryPayload = { entries: AccessDirectoryEntry[]; invitations: AccessInvitation[] };

function normalizeDirectoryPayload(value: unknown): DirectoryPayload {
  if (Array.isArray(value)) return { entries: value as AccessDirectoryEntry[], invitations: [] };
  if (value && typeof value === "object") {
    const payload = value as Partial<DirectoryPayload>;
    return { entries: Array.isArray(payload.entries) ? payload.entries : [], invitations: Array.isArray(payload.invitations) ? payload.invitations : [] };
  }
  return { entries: [], invitations: [] };
}

async function loadDirectory(signal: AbortSignal) {
  const response = await fetch(apiUrl("/api/access-directory"), { signal, cache: "no-store" });
  return normalizeDirectoryPayload(await requireLabCareResponse(response));
}

export function AccessDirectory({ user }: { user?: AppUser }) {
  const request = useRequest("labcare-access-directory", loadDirectory);
  const [addOpen, setAddOpen] = useState(false);
  const [inviteOpen, setInviteOpen] = useState(false);
  const [deactivate, setDeactivate] = useState<AccessDirectoryEntry | null>(null);
  const [revoke, setRevoke] = useState<AccessInvitation | null>(null);
  const [pending, setPending] = useState(false);

  if (!user || !can(user.roles, "manage_access_directory")) {
    return <main className="min-h-full bg-background px-4 py-10 sm:px-6"><div className="mx-auto max-w-3xl"><Card title="Access directory"><p className="text-sm text-muted-foreground">You do not have permission to manage access.</p></Card></div></main>;
  }

  async function add(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setPending(true);
    try {
      await requireLabCareResponse(await addLabCareAccessEntry(Object.fromEntries(new FormData(event.currentTarget).entries())));
      toast.success("User added to the directory");
      setAddOpen(false);
      request.refresh();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Unable to add user");
    } finally {
      setPending(false);
    }
  }

  async function invite(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setPending(true);
    try {
      await requireLabCareResponse(await inviteLabCareUser(Object.fromEntries(new FormData(event.currentTarget).entries())));
      toast.success("Invitation recorded as pending");
      setInviteOpen(false);
      request.refresh();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Unable to create invitation");
    } finally {
      setPending(false);
    }
  }

  async function remove() {
    if (!deactivate) return;
    setPending(true);
    try {
      await requireLabCareResponse(await deactivateLabCareAccessEntry(deactivate.id));
      toast.success("Access deactivated");
      setDeactivate(null);
      request.refresh();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Unable to deactivate access");
    } finally {
      setPending(false);
    }
  }

  async function cancelInvitation() {
    if (!revoke) return;
    setPending(true);
    try {
      await requireLabCareResponse(await revokeLabCareInvitation(revoke.id));
      toast.success("Invitation revoked");
      setRevoke(null);
      request.refresh();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Unable to revoke invitation");
    } finally {
      setPending(false);
    }
  }

  return <main className="min-h-full bg-background px-4 py-6 sm:px-6 lg:px-8"><div className="mx-auto max-w-6xl space-y-6">
    <PageHeader eyebrow="Administration" title="Access directory" actions={<div className="flex flex-wrap gap-2"><Button variant="outline" onClick={() => setAddOpen(true)}><UserPlus className="size-4" />Add known user</Button><Button variant="highlight" onClick={() => setInviteOpen(true)}><Mail className="size-4" />Invite by email</Button></div>} />
    <Card title="Directory access"><p className="border-b border-border px-4 py-3 text-sm text-muted-foreground">Active and deactivated LabCare Desk accounts</p><AsyncView result={request} isEmpty={(data) => data.entries.length === 0 && data.invitations.length === 0} empty={<p className="p-8 text-center text-sm text-muted-foreground">No directory entries or invitations.</p>}>{(data) => <div className="overflow-x-auto"><table className="w-full min-w-[760px] text-left text-sm"><thead className="bg-surface-inset text-xs uppercase tracking-wide text-muted-foreground"><tr><th className="px-4 py-3">User</th><th className="px-4 py-3">Email</th><th className="px-4 py-3">Phone</th><th className="px-4 py-3">Role</th><th className="px-4 py-3">Status</th><th className="px-4 py-3" /></tr></thead><tbody className="divide-y divide-border">
      {data.entries.map((entry) => <tr key={`entry-${entry.id}`}><td className="px-4 py-3 font-medium">{entry.displayName}<div className="text-xs font-normal text-muted-foreground">{entry.userId}</div></td><td className="px-4 py-3 text-muted-foreground">{entry.email ?? "—"}</td><td className="px-4 py-3 text-muted-foreground">{entry.phone || "—"}</td><td className="px-4 py-3">{entry.roleKey}</td><td className="px-4 py-3"><StatusBadge status={entry.status}>{entry.status}</StatusBadge></td><td className="px-4 py-3 text-right">{entry.status === "active" && <Button variant="ghost" size="sm" onClick={() => setDeactivate(entry)}><UserX className="size-4" />Deactivate</Button>}</td></tr>)}
      {data.invitations.map((invitation) => <tr key={`invitation-${invitation.id}`}><td className="px-4 py-3 font-medium">{invitation.displayName}<div className="text-xs font-normal text-muted-foreground">Invitation</div></td><td className="px-4 py-3 text-muted-foreground">{invitation.email}</td><td className="px-4 py-3 text-muted-foreground">{invitation.phone}</td><td className="px-4 py-3">{invitation.roleKey}</td><td className="px-4 py-3"><StatusBadge status={invitation.status}>{invitation.status === "pending" ? "Pending · platform setup" : "Revoked"}</StatusBadge></td><td className="px-4 py-3 text-right">{invitation.status === "pending" && <Button variant="ghost" size="sm" onClick={() => setRevoke(invitation)}><Ban className="size-4" />Revoke</Button>}</td></tr>)}
    </tbody></table></div>}</AsyncView></Card>

    <FormDialog open={inviteOpen} onOpenChange={setInviteOpen} title="Invite user by email" description="Record a pending invitation for a Gateway administrator to provision. This app does not send email or create Gateway accounts." submitLabel="Create invitation" pending={pending} onSubmit={invite}><FormGrid><FieldGroup label="Email" htmlFor="invite-email" required helperText="The invitee's email is normalized to lowercase."><input id="invite-email" name="email" type="email" required maxLength={320} className="field-control w-full max-w-sm" /></FieldGroup><FieldGroup label="Display name" htmlFor="invite-display-name" required><input id="invite-display-name" name="displayName" required maxLength={200} className="field-control" /></FieldGroup></FormGrid><FormGrid><FieldGroup label="Phone" htmlFor="invite-phone" required helperText="Used for phone notifications when configured."><input id="invite-phone" name="phone" type="tel" required className="field-control" /></FieldGroup><FieldGroup label="Role" htmlFor="invite-role" required><select id="invite-role" name="roleKey" required defaultValue="customer" className="field-control"><option value="support_team">Support Team</option><option value="customer">Customer</option><option value="viewer">Viewer</option></select></FieldGroup></FormGrid></FormDialog>
    <FormDialog open={addOpen} onOpenChange={setAddOpen} title="Add known user" description="Add an existing Gateway user to the LabCare Desk directory." submitLabel="Add user" pending={pending} onSubmit={add}><FormGrid><FieldGroup label="User ID" htmlFor="userId" required><input id="userId" name="userId" required maxLength={200} className="field-control" /></FieldGroup><FieldGroup label="Display name" htmlFor="displayName" required><input id="displayName" name="displayName" required maxLength={200} className="field-control" /></FieldGroup></FormGrid><FormGrid><FieldGroup label="Email" htmlFor="email" required><input id="email" name="email" type="email" required maxLength={320} className="field-control" /></FieldGroup><FieldGroup label="Phone" htmlFor="phone" required helperText="Used for phone notifications when configured."><input id="phone" name="phone" type="tel" required className="field-control" /></FieldGroup><FieldGroup label="Role" htmlFor="roleKey" required><select id="roleKey" name="roleKey" required className="field-control"><option value="support_team">Support Team</option><option value="customer">Customer</option><option value="viewer">Viewer</option></select></FieldGroup></FormGrid></FormDialog>
    <ConfirmDialog open={Boolean(deactivate)} onOpenChange={(value) => !value && setDeactivate(null)} title="Deactivate access?" description={`Deactivating ${deactivate?.displayName ?? "this user"} removes their LabCare Desk directory access. Existing ticket history is preserved.`} confirmLabel="Deactivate" destructive pending={pending} onConfirm={remove} />
    <ConfirmDialog open={Boolean(revoke)} onOpenChange={(value) => !value && setRevoke(null)} title="Revoke invitation?" description={`Revoking the invitation for ${revoke?.email ?? "this email"} removes its pending status. No Gateway account or email was created by this action.`} confirmLabel="Revoke invitation" destructive pending={pending} onConfirm={cancelInvitation} />
  </div></main>;
}
