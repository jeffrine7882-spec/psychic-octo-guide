import type { Equipment, Notification, Ticket, TicketHistory } from "@/db/schema";

export type TicketRow = { ticket: Ticket; equipment: Equipment | null };
export type TicketDetailData = TicketRow & { history: TicketHistory[]; notifications: Notification[] };

export const statuses: Ticket["status"][] = ["new", "triaged", "in_progress", "waiting_on_customer", "resolved", "closed"];
export const statusLabels: Record<Ticket["status"], string> = {
  new: "New", triaged: "Triaged", in_progress: "In progress", waiting_on_customer: "Waiting on customer", resolved: "Resolved", closed: "Closed",
};
export const priorityLabels: Record<Ticket["priority"], string> = { low: "Low", normal: "Normal", high: "High", urgent: "Urgent" };
export const typeLabels: Record<Ticket["type"], string> = { complaint: "Complaint", breakdown: "Breakdown" };
export const equipmentOptions = [
  { id: "eq-microscope-01", label: "LC-MIC-001 · Inverted Microscope" },
  { id: "eq-analyzer-02", label: "LC-ANA-014 · Chemistry Analyzer" },
  { id: "eq-freezer-03", label: "LC-FRZ-007 · Ultra-low Freezer" },
];
export const notificationChannelLabels: Record<Notification["channel"], string> = { in_app: "In-app", email: "Email", phone: "Phone" };
export const notificationDeliveryStatusLabels: Record<Notification["deliveryStatus"], string> = { delivered: "Delivered", not_configured: "Not configured" };
export function formatDate(value: Date | string | null | undefined) {
  if (!value) return "—";
  return new Intl.DateTimeFormat("en", { dateStyle: "medium", timeStyle: "short" }).format(new Date(value));
}
export function humanize(value: string) { return value.replaceAll("_", " ").replace(/\b\w/g, (c) => c.toUpperCase()); }
