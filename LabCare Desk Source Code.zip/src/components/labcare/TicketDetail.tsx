import { useState, type FormEvent } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowLeft, Bell, Clock3, Mail, Phone, Save, UserRound } from "lucide-react";
import { toast } from "sonner";
import { apiUrl } from "@/lib/utils";
import { useRequest } from "@/lib/hooks";
import { can } from "@/lib/permissions";
import type { AppUser } from "@/lib/users";
import { requireLabCareResponse, updateLabCareTicket } from "@/lib/labcare-api";
import { AsyncView } from "@/components/data/async-view";
import { FieldGroup, FormGrid } from "@/components/forms/form-layout";
import { Button, Card, PageHeader, StatusBadge } from "@/components/ui";
import { formatDate, humanize, notificationChannelLabels, notificationDeliveryStatusLabels, priorityLabels, statuses, statusLabels, type TicketDetailData } from "./types";

async function loadDetail(ticketNumber: string, signal: AbortSignal) {
  const response = await fetch(apiUrl(`/api/tickets?ticketNumber=${encodeURIComponent(ticketNumber)}`), { signal, cache: "no-store" });
  return await requireLabCareResponse(response) as TicketDetailData;
}

const channelIcons = { in_app: Bell, email: Mail, phone: Phone };

export function TicketDetail({ ticketNumber, user }: { ticketNumber: string; user?: AppUser }) {
  const request = useRequest(`labcare-ticket:${ticketNumber}`, (signal) => loadDetail(ticketNumber, signal));
  const [pending, setPending] = useState(false);
  if (!user) return null;

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setPending(true);
    const form = new FormData(event.currentTarget);
    const payload = Object.fromEntries([...form.entries()].filter(([, value]) => String(value).trim() !== ""));
    try {
      await requireLabCareResponse(await updateLabCareTicket(Number(ticketNumber), payload));
      toast.success("Ticket updated");
      request.refresh();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Unable to update ticket");
    } finally {
      setPending(false);
    }
  }

  const canUpdateTicket = can(user.roles, "update_ticket");
  const canAddTicketNote = can(user.roles, "add_ticket_note");

  return (
    <main className="min-h-full bg-background px-4 py-6 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl space-y-6">
        <Link to="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"><ArrowLeft className="size-4" />Back to inbox</Link>
        <AsyncView result={request}>
          {(data) => (
            <>
              <PageHeader eyebrow={`Ticket ${data.ticket.ticketNumber}`} title={data.ticket.subject} actions={<StatusBadge status={data.ticket.status}>{statusLabels[data.ticket.status]}</StatusBadge>} />
              <div className="grid gap-6 lg:grid-cols-[1fr_340px]">
                <div className="space-y-6">
                  <Card title="Ticket summary">
                    <div className="grid gap-4 sm:grid-cols-2">
                      <Info label="Ticket number" value={<span className="font-mono">{data.ticket.ticketNumber}</span>} />
                      <Info label="Type" value={humanize(data.ticket.type)} />
                      <Info label="Priority" value={priorityLabels[data.ticket.priority]} />
                      <Info label="Equipment" value={data.equipment ? `${data.equipment.assetTag} · ${data.equipment.name}` : "Not specified"} />
                      <Info label="Created by" value={`${data.ticket.creatorName}${data.ticket.creatorEmail ? ` · ${data.ticket.creatorEmail}` : ""}`} />
                      <Info label="Assigned to" value={data.ticket.assignedTo ?? "Unassigned"} />
                    </div>
                    <div className="mt-5 border-t border-border pt-5"><p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Description</p><p className="mt-2 whitespace-pre-wrap text-sm leading-6">{data.ticket.description}</p></div>
                    {data.ticket.resolution && <div className="mt-5 border-t border-border pt-5"><p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Resolution</p><p className="mt-2 whitespace-pre-wrap text-sm leading-6">{data.ticket.resolution}</p></div>}
                  </Card>
                  <Card title="History"><div className="space-y-5">{data.history.map((entry) => <div key={entry.id} className="relative pl-8"><span className="absolute left-0 top-1 grid size-5 place-items-center rounded-full bg-surface-inset text-muted-foreground"><Clock3 className="size-3" /></span><p className="text-sm font-medium">{humanize(entry.action)}{entry.toStatus ? <span className="ml-2"><StatusBadge status={entry.toStatus}>{statusLabels[entry.toStatus]}</StatusBadge></span> : null}</p><p className="mt-1 text-xs text-muted-foreground">{entry.actorName} · {formatDate(entry.createdAt)}</p>{entry.note && <p className="mt-2 whitespace-pre-wrap text-sm leading-6 text-secondary-foreground">{entry.note}</p>}</div>)}</div></Card>
                  <Card title="Notification delivery"><div className="space-y-3">{data.notifications.length ? data.notifications.map((notification) => { const Icon = channelIcons[notification.channel]; return <div key={notification.id} className="flex gap-3 rounded-md border border-border p-3"><Icon className="mt-0.5 size-4 shrink-0 text-muted-foreground" /><div><div className="flex flex-wrap gap-2 text-sm font-medium"><span>{notification.title}</span><span className="rounded-full bg-surface-inset px-2 py-0.5 text-[11px] font-normal text-muted-foreground">{notificationChannelLabels[notification.channel]} · {notificationDeliveryStatusLabels[notification.deliveryStatus]}</span></div><p className="mt-1 text-sm text-muted-foreground">{notification.message}</p><p className="mt-1 text-xs text-muted-foreground">{formatDate(notification.createdAt)}</p></div></div>; }) : <p className="text-sm text-muted-foreground">No notifications recorded for this ticket.</p>}</div></Card>
                </div>
                <div>
                  {canUpdateTicket && <Card title="Update ticket"><form className="space-y-4" onSubmit={submit}><FormGrid columns={1}><FieldGroup label="Status" htmlFor="status"><select id="status" name="status" defaultValue={data.ticket.status} className="field-control">{statuses.map((item) => <option key={item} value={item}>{statusLabels[item]}</option>)}</select></FieldGroup><FieldGroup label="Assignment" htmlFor="assignedTo"><input id="assignedTo" name="assignedTo" defaultValue={data.ticket.assignedTo ?? ""} placeholder="User id or team" className="field-control" /></FieldGroup><FieldGroup label="Resolution" htmlFor="resolution"><textarea id="resolution" name="resolution" rows={4} defaultValue={data.ticket.resolution ?? ""} placeholder="Add resolution when closing" className="field-control resize-y" /></FieldGroup><FieldGroup label="Internal or customer note" htmlFor="note"><textarea id="note" name="note" rows={4} placeholder="Record the next update" className="field-control resize-y" /></FieldGroup></FormGrid><Button type="submit" disabled={pending}><Save className="size-4" />{pending ? "Saving…" : "Save update"}</Button></form></Card>}
                  {canAddTicketNote && !canUpdateTicket && data.ticket.creatorId === user.id && <CustomerNote ticketNumber={data.ticket.ticketNumber} onSaved={request.refresh} />}
                </div>
              </div>
            </>
          )}
        </AsyncView>
      </div>
    </main>
  );
}

function Info({ label, value }: { label: string; value: React.ReactNode }) {
  return <div><p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">{label}</p><p className="mt-1 text-sm">{value}</p></div>;
}

function CustomerNote({ ticketNumber, onSaved }: { ticketNumber: number; onSaved: () => void }) {
  const [pending, setPending] = useState(false);
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setPending(true);
    const note = String(new FormData(event.currentTarget).get("note") ?? "").trim();
    try {
      await requireLabCareResponse(await updateLabCareTicket(ticketNumber, { note }));
      toast.success("Note added");
      event.currentTarget.reset();
      onSaved();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Unable to add note");
    } finally {
      setPending(false);
    }
  }
  return <Card title="Add a note"><form onSubmit={submit} className="space-y-4"><FieldGroup label="Message" htmlFor="note"><textarea id="note" name="note" required minLength={1} rows={5} className="field-control resize-y" placeholder="Share an update with support" /></FieldGroup><Button type="submit" disabled={pending}><UserRound className="size-4" />{pending ? "Sending…" : "Add note"}</Button></form></Card>;
}
