import { APP_HOME_ROUTE, getAppChromeSafeRoute } from "./app-chrome";

export interface RoleMetadata {
  label: string;
  description: string;
  defaultRoute: string;
}

export const VIEWER_METADATA = {
  label: "Viewer",
  description: "Views tickets and notification delivery history without changing records.",
  defaultRoute: APP_HOME_ROUTE,
} as const satisfies RoleMetadata;

export const ROLE_METADATA = {
  admin: {
    label: "Admin",
    description: "Full access to all features and settings.",
    defaultRoute: APP_HOME_ROUTE,
  },
  support_team: {
    label: "Support Team",
    description: "Manages laboratory equipment support tickets and equipment registration.",
    defaultRoute: APP_HOME_ROUTE,
  },
  customer: {
    label: "Customer",
    description: "Reports and follows up on laboratory equipment issues.",
    defaultRoute: APP_HOME_ROUTE,
  },
} as const satisfies Record<string, RoleMetadata>;

export type RoleKey = keyof typeof ROLE_METADATA;

export function getRoleMetadata(role: string): RoleMetadata {
  const metadata = role === "viewer" ? VIEWER_METADATA : ROLE_METADATA[role as RoleKey] ?? {
    label: role,
    description: "Role description is not configured.",
    defaultRoute: APP_HOME_ROUTE,
  };

  return {
    ...metadata,
    defaultRoute: getAppChromeSafeRoute(metadata.defaultRoute),
  };
}
