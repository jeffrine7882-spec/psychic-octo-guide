import { APP_HOME_ROUTE } from "./app-chrome";

/** Keep the Gateway handoff from becoming an open redirect. */
export function getSafeLoginDestination(value: unknown): string {
  if (typeof value !== "string" || !value.startsWith("/") || value.startsWith("//")) {
    return APP_HOME_ROUTE;
  }

  try {
    const destination = new URL(value, "https://labcare.invalid");
    return destination.origin === "https://labcare.invalid"
      ? `${destination.pathname}${destination.search}${destination.hash}`
      : APP_HOME_ROUTE;
  } catch {
    return APP_HOME_ROUTE;
  }
}
