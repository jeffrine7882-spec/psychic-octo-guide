import { apiUrl } from "@/lib/utils";

/** Client-callable API paths for the LabCare Desk workspace. */
export async function createLabCareTicket(input: unknown) {
  return fetch(apiUrl("/api/tickets"), {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(input),
  });
}

export async function updateLabCareTicket(ticketNumber: number, input: unknown) {
  const params = new URLSearchParams({ ticketNumber: String(ticketNumber) });
  return fetch(apiUrl(`/api/tickets?${params.toString()}`), {
    method: "PATCH",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(input),
  });
}

export async function addLabCareAccessEntry(input: unknown) {
  return fetch(apiUrl("/api/access-directory"), {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(input),
  });
}

export async function inviteLabCareUser(input: unknown) {
  return fetch(apiUrl("/api/access-invitations"), {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(input),
  });
}

export async function revokeLabCareInvitation(id: string) {
  return fetch(apiUrl(`/api/access-invitations?id=${encodeURIComponent(id)}`), {
    method: "PATCH",
  });
}

export async function deactivateLabCareAccessEntry(id: string) {
  return fetch(apiUrl(`/api/access-directory?id=${encodeURIComponent(id)}`), {
    method: "PATCH",
  });
}

export async function deactivateLabCareEquipment(id: string) {
  return fetch(apiUrl(`/api/equipment?id=${encodeURIComponent(id)}`), {
    method: "PATCH",
  });
}

export async function addLabCareEquipment(input: unknown) {
  return fetch(apiUrl("/api/equipment"), {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(input),
  });
}

export async function markLabCareNotificationRead(id: string) {
  return fetch(apiUrl(`/api/notifications?id=${encodeURIComponent(id)}`), {
    method: "PATCH",
  });
}

export async function requireLabCareResponse(response: Response) {
  if (!response.ok) {
    const body = await response.json().catch(() => null) as { error?: string } | null;
    throw new Error(body?.error ?? `Request failed (${response.status})`);
  }
  return response.json();
}
