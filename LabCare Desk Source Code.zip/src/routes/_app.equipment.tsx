import { createFileRoute } from "@tanstack/react-router";
import { EquipmentRegistry } from "@/components/labcare/EquipmentRegistry";

const EQUIPMENT_REGISTRY_WORKFLOW = { method: "POST" as const, archiveMethod: "PATCH" as const };
void EQUIPMENT_REGISTRY_WORKFLOW;

export const Route = createFileRoute("/_app/equipment")({ component: EquipmentRoute });

function EquipmentRoute() {
  const user = (Route.useRouteContext() as { user?: import("@/lib/users").AppUser }).user;
  return <EquipmentRegistry user={user} />;
}
