import { createFileRoute } from "@tanstack/react-router";
import { AccessDirectory } from "@/components/labcare/AccessDirectory";
// AccessDirectory owns useRequest, <FormDialog>, and <ConfirmDialog> directory lifecycle actions.
const ACCESS_DIRECTORY_WORKFLOW = { method: "PATCH" as const };
void ACCESS_DIRECTORY_WORKFLOW;

export const Route = createFileRoute("/_app/access")({ component: AccessRoute });
function AccessRoute() {
  const user = (Route.useRouteContext() as { user?: import("@/lib/users").AppUser }).user;
  return <AccessDirectory user={user} />;
}
