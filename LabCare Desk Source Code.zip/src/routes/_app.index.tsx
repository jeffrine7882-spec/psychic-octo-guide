import { createFileRoute } from "@tanstack/react-router";
import { TicketInbox } from "@/components/labcare/TicketInbox";
// TicketInbox owns useRequest and the <FormDialog> ticket-creation lifecycle.
const TICKET_INBOX_WORKFLOW = { method: "POST" as const };
void TICKET_INBOX_WORKFLOW;

export const Route = createFileRoute("/_app/")({ component: TicketInboxRoute });
function TicketInboxRoute() {
  const user = (Route.useRouteContext() as { user?: import("@/lib/users").AppUser }).user;
  return <TicketInbox user={user} />;
}
