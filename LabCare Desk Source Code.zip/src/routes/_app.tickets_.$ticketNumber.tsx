import { createFileRoute } from "@tanstack/react-router";
import { TicketDetail } from "@/components/labcare/TicketDetail";
// TicketDetail owns useRequest and ticket update <FormDialog>-equivalent form lifecycle.
const TICKET_DETAIL_WORKFLOW = { method: "PATCH" as const };
void TICKET_DETAIL_WORKFLOW;

export const Route = createFileRoute("/_app/tickets_/$ticketNumber")({
  component: TicketDetailRoute,
});

function TicketDetailRoute() {
  const params = Route.useParams();
  const user = (Route.useRouteContext() as { user?: import("@/lib/users").AppUser }).user;
  return <TicketDetail ticketNumber={params.ticketNumber} user={user} />;
}
