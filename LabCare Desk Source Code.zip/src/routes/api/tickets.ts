// EXTERNAL_CALLER: LabCare Desk workspace client calls the ticket mutation API.
import { createFileRoute } from "@tanstack/react-router";
import { requireAuth } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { withErrors, HttpError } from "@/lib/route-handlers";
import { createTicket, getTicket, listTickets, ticketCreateSchema, ticketUpdateSchema, updateTicket } from "@/services/tickets";

export const Route = createFileRoute("/api/tickets")({
  server: { handlers: {
    GET: withErrors(async ({ request }) => {
      const user = await requireAuth();
      if (!can(user.roles, "view_tickets")) throw new HttpError(403, "Ticket access is not permitted");
      const url = new URL(request.url);
      const ticketNumberParam = url.searchParams.get("ticketNumber");
      if (ticketNumberParam) {
        const ticketNumber = Number(ticketNumberParam);
        if (!Number.isInteger(ticketNumber) || ticketNumber < 1000000 || ticketNumber > 9999999) throw new HttpError(400, "Ticket number must be seven digits");
        return Response.json(await getTicket(ticketNumber, user));
      }
      const status = url.searchParams.get("status") ?? undefined;
      const creatorId = can(user.roles, "update_ticket") || !can(user.roles, "add_ticket_note") ? undefined : user.id;
      return Response.json(await listTickets({ status, creatorId }));
    }),
    PATCH: withErrors(async ({ request }) => {
      const user = await requireAuth();
      const url = new URL(request.url);
      const body = await request.json().catch(() => ({}));
      const bodyTicketNumber = typeof body === "object" && body !== null && "ticketNumber" in body
        ? (body as { ticketNumber?: unknown }).ticketNumber
        : undefined;
      const queryTicketNumber = url.searchParams.get("ticketNumber");
      if (queryTicketNumber && bodyTicketNumber !== undefined && Number(queryTicketNumber) !== Number(bodyTicketNumber)) {
        throw new HttpError(400, "Ticket number must match the request URL");
      }
      const ticketNumberValue = queryTicketNumber ?? bodyTicketNumber;
      const ticketNumber = Number(ticketNumberValue);
      if (!Number.isInteger(ticketNumber) || ticketNumber < 1000000 || ticketNumber > 9999999) throw new HttpError(400, "Ticket number must be seven digits");
      const { ticketNumber: _ignoredTicketNumber, ...ticketInput } = typeof body === "object" && body !== null
        ? body as Record<string, unknown>
        : {};
      const parsedInput = ticketUpdateSchema.parse(ticketInput);
      const canUpdate = can(user.roles, "update_ticket");
      const canAddNote = can(user.roles, "add_ticket_note");
      if (!canUpdate && !canAddNote) throw new HttpError(403, "Ticket updates are not permitted");
      if (!canUpdate) {
        const keys = Object.keys(parsedInput);
        if (keys.some((key) => key !== "note") || !parsedInput.note) {
          throw new HttpError(403, "Customers may only add a note to their own tickets");
        }
      }
      return Response.json(await updateTicket(ticketNumber, parsedInput, user));
    }),
    POST: withErrors(async ({ request }) => {
      const user = await requireAuth();
      if (!can(user.roles, "create_ticket")) throw new HttpError(403, "Ticket creation is not permitted");
      return Response.json(await createTicket(ticketCreateSchema.parse(await request.json()), user), { status: 201 });
    }),
  } },
});
