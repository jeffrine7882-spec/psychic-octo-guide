import { createFileRoute } from "@tanstack/react-router";
import { requireAuth } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { withErrors, HttpError } from "@/lib/route-handlers";
import { accessInvitationSchema, createAccessInvitation, revokeAccessInvitation } from "@/services/access-directory";

export const Route = createFileRoute("/api/access-invitations")({
  server: { handlers: {
    POST: withErrors(async ({ request }) => {
      const user = await requireAuth();
      if (!can(user.roles, "manage_access_directory")) throw new HttpError(403, "Only administrators can invite users");
      return Response.json(await createAccessInvitation(accessInvitationSchema.parse(await request.json()), { id: user.id, displayName: user.displayName }), { status: 201 });
    }),
    PATCH: withErrors(async ({ request }) => {
      const user = await requireAuth();
      if (!can(user.roles, "manage_access_directory")) throw new HttpError(403, "Only administrators can revoke invitations");
      const id = new URL(request.url).searchParams.get("id");
      if (!id) throw new HttpError(400, "Invitation id is required");
      return Response.json(await revokeAccessInvitation(id));
    }),
  } },
});
