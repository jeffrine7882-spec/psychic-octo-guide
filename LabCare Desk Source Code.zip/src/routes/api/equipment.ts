// EXTERNAL_CALLER: LabCare Desk workspace equipment registry calls these mutations.
import { createFileRoute } from "@tanstack/react-router";
import { requireAuth } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { HttpError, withErrors } from "@/lib/route-handlers";
import { createEquipment, deactivateEquipment, equipmentCreateSchema, listEquipment } from "@/services/tickets";

export const Route = createFileRoute("/api/equipment")({
  server: { handlers: {
    GET: withErrors(async () => {
      const user = await requireAuth();
      if (!can(user.roles, "view_tickets")) throw new HttpError(403, "Equipment access is not permitted");
      return Response.json(await listEquipment(can(user.roles, "manage_equipment")));
    }),
    POST: withErrors(async ({ request }) => {
      const user = await requireAuth();
      if (!can(user.roles, "manage_equipment")) throw new HttpError(403, "Equipment registration is not permitted");
      return Response.json(await createEquipment(equipmentCreateSchema.parse(await request.json())), { status: 201 });
    }),
    PATCH: withErrors(async ({ request }) => {
      const user = await requireAuth();
      if (!can(user.roles, "manage_equipment")) throw new HttpError(403, "Equipment deactivation is not permitted");
      const id = new URL(request.url).searchParams.get("id");
      if (!id) throw new HttpError(400, "Equipment id is required");
      return Response.json(await deactivateEquipment(id));
    }),
  } },
});
