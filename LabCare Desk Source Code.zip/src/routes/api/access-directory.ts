// EXTERNAL_CALLER: LabCare Desk workspace client calls the access-directory mutation API.
import { createFileRoute } from "@tanstack/react-router";
import { requireAuth } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { withErrors, HttpError } from "@/lib/route-handlers";
import { accessEntrySchema, addAccessEntry, deactivateAccessEntry, listAccessDirectory, listAccessInvitations } from "@/services/access-directory";

export const Route = createFileRoute("/api/access-directory")({
  server: { handlers: {
    GET: withErrors(async () => {
      const user = await requireAuth();
      if (!can(user.roles, "manage_access_directory")) throw new HttpError(403, "Access directory access is not permitted");
      return Response.json({ entries: await listAccessDirectory(true), invitations: await listAccessInvitations() });
    }),
    POST: withErrors(async ({ request }) => {
      const user = await requireAuth();
      if (!can(user.roles, "manage_access_directory")) throw new HttpError(403, "Only administrators can add access entries");
      return Response.json(await addAccessEntry(accessEntrySchema.parse(await request.json())), { status: 201 });
    }),
    PATCH: withErrors(async ({ request }) => {
      const user = await requireAuth();
      if (!can(user.roles, "manage_access_directory")) throw new HttpError(403, "Only administrators can deactivate access entries");
      const id = new URL(request.url).searchParams.get("id");
      if (!id) throw new HttpError(400, "Access entry id is required");
      return Response.json(await deactivateAccessEntry(id));
    }),
  } },
});
