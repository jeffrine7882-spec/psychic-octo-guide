import { createFileRoute } from "@tanstack/react-router";
import { requireAuth } from "@/lib/auth";
import { can } from "@/lib/permissions";
import { withErrors, HttpError } from "@/lib/route-handlers";
import { listNotifications, markNotificationRead } from "@/services/tickets";

export const Route = createFileRoute("/api/notifications")({
  server: { handlers: {
    GET: withErrors(async ({ request }) => {
      const user = await requireAuth();
      if (!can(user.roles, "view_notifications")) throw new HttpError(403, "Notification access is not permitted");
      const unread = new URL(request.url).searchParams.get("unread") === "true";
      return Response.json(await listNotifications(user.id, unread));
    }),
    PATCH: withErrors(async ({ request }) => {
      const user = await requireAuth();
      if (!can(user.roles, "update_notifications")) throw new HttpError(403, "Notification updates are not permitted");
      const id = new URL(request.url).searchParams.get("id");
      if (!id) throw new HttpError(400, "Notification id is required");
      return Response.json(await markNotificationRead(id, user.id));
    }),
  } },
});
