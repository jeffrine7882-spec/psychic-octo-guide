import { createFileRoute } from "@tanstack/react-router";
import { ArrowRight, LockKeyhole, LifeBuoy } from "lucide-react";
import { APP_ICON, APP_NAME } from "@/lib/app-chrome";
import { getSafeLoginDestination } from "@/lib/login";

export const Route = createFileRoute("/login")({
  component: LoginHandoff,
});

function LoginHandoff() {
  const search = new URLSearchParams(typeof window === "undefined" ? "" : window.location.search);
  const destination = getSafeLoginDestination(search.get("from"));

  return (
    <main className="flex min-h-screen items-center justify-center bg-surface-inset px-4 py-8 sm:px-6">
      <div className="w-full max-w-md">
        <div className="mb-6 flex items-center gap-3">
          <div className="grid size-11 shrink-0 place-items-center overflow-hidden rounded-lg border border-highlight-bg-primary bg-highlight-bg-accent">
            <img src={APP_ICON} alt={`${APP_NAME} icon`} className="size-full object-cover" />
          </div>
          <div>
            <p className="text-lg font-semibold tracking-tight">{APP_NAME}</p>
            <p className="caption">Laboratory equipment support</p>
          </div>
        </div>
        <section className="rounded-xl border border-border bg-card p-6 shadow-sm sm:p-8">
          <div className="grid size-11 place-items-center rounded-full bg-surface-inset text-highlight-deep">
            <LockKeyhole className="size-5" aria-hidden="true" />
          </div>
          <p className="mt-6 text-xs font-semibold uppercase tracking-[0.16em] text-muted-foreground">Secure sign-in</p>
          <h1 className="mt-2 text-2xl font-semibold tracking-tight text-foreground">Continue to {APP_NAME}</h1>
          <p className="mt-3 text-sm leading-6 text-muted-foreground">
            Sign-in is handled securely by the Tier0 Gateway. Continue there to verify your identity and return to your requested workspace.
          </p>
          <a
            href={destination}
            className="mt-6 inline-flex h-10 w-full items-center justify-center gap-2 rounded-md bg-primary px-4 text-sm font-medium text-primary-foreground transition-colors hover:bg-[color:var(--tier0-primary-hover)] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"
          >
            Retry / continue <ArrowRight className="size-4" aria-hidden="true" />
          </a>
          <p className="mt-4 break-words text-center font-mono text-xs text-muted-foreground">
            Destination: {destination}
          </p>
        </section>
        <div className="mt-5 flex gap-3 rounded-lg border border-border-secondary bg-card/70 p-4 text-sm text-muted-foreground">
          <LifeBuoy className="mt-0.5 size-4 shrink-0 text-highlight-deep" aria-hidden="true" />
          <p>If you still cannot sign in, contact your laboratory support administrator. They can verify your Gateway access.</p>
        </div>
      </div>
    </main>
  );
}
