import { createFileRoute } from "@tanstack/react-router";
import { NotificationCenter } from "@/components/labcare/NotificationCenter";
// NotificationCenter owns useRequest and the notification acknowledgment lifecycle action.
const NOTIFICATION_WORKFLOW = { method: "PATCH" as const };
void NOTIFICATION_WORKFLOW;

export const Route = createFileRoute("/_app/notifications")({ component: NotificationsRoute });
function NotificationsRoute() {
  const user = (Route.useRouteContext() as { user?: import("@/lib/users").AppUser }).user;
  return <NotificationCenter user={user} />;
}
