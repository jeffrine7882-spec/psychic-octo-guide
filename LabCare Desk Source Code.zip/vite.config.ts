import { defineConfig, type Plugin } from "vite";
import { tanstackStart } from "@tanstack/react-start/plugin/vite";
import viteReact from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

const allowAllHosts = process.env.VITE_ALLOWED_HOSTS === "all";
const strictPort = process.env.VITE_STRICT_PORT !== "false";

function previewGatewayHeaders(): Plugin {
  // Managed Executor iframes can reach Vite directly without the platform
  // gateway hop. Keep a local-only identity so the authenticated workspace can
  // render in that case; deployed requests still rely exclusively on gateway
  // identity headers, and incoming headers always take precedence.
  const isDevelopment = process.env.NODE_ENV !== "production";
  const previewUserId =
    process.env.PREVIEW_USER_ID || (isDevelopment ? "preview-user" : undefined);
  const previewUserName =
    process.env.PREVIEW_USER_NAME || (isDevelopment ? "Preview User" : undefined);
  const previewUserEmail =
    process.env.PREVIEW_USER_EMAIL || (isDevelopment ? "preview@example.com" : "");
  const previewUserRole =
    process.env.PREVIEW_USER_ROLE || (isDevelopment ? "admin" : "");

  return {
    name: "preview-gateway-headers",
    enforce: "pre" as const,
    configureServer(server) {
      if (!previewUserId) return;

      const injectPreviewHeaders = (req: { headers: Record<string, string | string[] | undefined> }, _res: unknown, next: () => void) => {
        req.headers["x-app-user-id"] ??= previewUserId;
        if (previewUserName) {
          req.headers["x-app-user-name"] ??= previewUserName;
        }
        if (previewUserEmail) {
          req.headers["x-app-user-email"] ??= previewUserEmail;
        }
        req.headers["x-tier0-runtime"] ??= "preview";
        if (previewUserRole) {
          req.headers["x-tier0-preview-role"] ??= previewUserRole;
        }
        next();
      };

      // TanStack Start installs its request handler during Vite setup. Put the
      // local preview identity ahead of that handler so direct Executor iframe
      // requests receive the same request-scoped context as gateway requests.
      const middlewareStack = (server.middlewares as typeof server.middlewares & {
        stack?: Array<{ route: string; handle: typeof injectPreviewHeaders }>;
      }).stack;
      if (middlewareStack) {
        middlewareStack.unshift({ route: "", handle: injectPreviewHeaders });
      } else {
        server.middlewares.use(injectPreviewHeaders);
      }
    },
  };
}

export default defineConfig({

  base: process.env.VITE_BASE_PATH || process.env.NEXT_PUBLIC_BASE_PATH || "/",
  server: {
    watch: {
      // Sandbox session data is not application source. Ignoring it prevents
      // wire.jsonl appends from being amplified into full-page reloads.
      ignored: ["**/.tier0/**"],
    },
    port: 5173,
    strictPort,
    host: "0.0.0.0",
    allowedHosts: allowAllHosts ? true : [],
    forwardConsole: true,
  },
  resolve: {
    tsconfigPaths: true,
  },
  ssr: {
    external: ["pg", "@tier0/sdk", "mqtt"],
  },
  optimizeDeps: {
    // Pre-bundle client deps that are only reached through code-split route
    // boundaries. If Vite discovers one of these *after* the initial scan it
    // re-optimizes and forces a full page reload, breaking HMR. List the exact
    // subpath that is actually imported (e.g. "motion/react", not "motion").
    include: [
      "lucide-react",
      "motion/react",
      "clsx",
      "tailwind-merge",
      "sonner",
    ],
  },
  plugins: [
    previewGatewayHeaders(),
    tailwindcss(),
    tanstackStart({
      srcDirectory: "src",
      router: {
        basepath:
          process.env.VITE_BASE_PATH || process.env.NEXT_PUBLIC_BASE_PATH || undefined,
      },
    }),
    viteReact(),
  ],
});
